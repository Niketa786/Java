package Object;

public class Student {
int rollno;
String name;
int marks;

void Study() {
	System.out.println("Studying");
}
void Sleep() {
	System.out.println("Sleeping");
}
void Eat() {
	System.out.println("Eating");
}
}
