package Object;

public class Employee1 {
	public static void main(String[] args) {
		Employee e1 = new Employee();
		e1.id = 10;
		e1.name = "Niketa";
		System.out.println(e1.id);
		System.out.println(e1.name);
		e1.Work();

		Employee e2 = new Employee();
		e2.id = 11;
		e2.name = "mahi";
		System.out.println(e2.id);
		System.out.println(e2.name);
		e2.Work();
		} 
}
