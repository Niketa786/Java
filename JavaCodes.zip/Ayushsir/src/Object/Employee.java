package Object;

public class Employee {
int id;
String name;

void Work() {
	System.out.println("working");
}
}
