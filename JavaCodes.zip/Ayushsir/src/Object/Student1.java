package Object;

public class Student1 {
	public static void main(String[] args) {
		Student s1 = new Student();
		s1.rollno = 12;
		s1.name = "Ajay";
		s1.marks = 85;
		System.out.println(s1.rollno);
		System.out.println(s1.name);
		System.out.println(s1.marks);
		s1.Study();
		s1.Sleep();
		s1.Eat();

	}
}
