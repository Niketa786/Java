package FinalKeyword;

//finalvariable
//public class Parent {
//final int a = 10;
//void display() {
//	a = 99;         //it is giving error for final variable act as constant that value cannot be changed
//	System.out.println(a);
//}
//}
//


//final method
//public class Parent {
//final int a = 10;
//    final void display() {        
//	System.out.println(a);
//}
//}
//
//
//public class Child extends parent {     //it is giving error for finalmethod for cannot overriding the method
//	void display() {
//		System.out.println("Inside child display");
//	}
//}


//finalClass
final class Parent {
final int a = 10;
    void display() {        
	System.out.println(a);
}
}


public class Child extends parent {     //it is giving error for finalclass for cannot inherite the another class 
	void display() {
		System.out.println("Inside child display");
	}
}










