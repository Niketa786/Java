package FinalKeyword;

public class Main {
public static void main(String[] args) {
	Professor pro = new Professor();
	pro.id = 1;
	pro.conductLecture();
	pro.showID();
	Student st= new Student();
	st.id = 2;
	st.attendLecture();
	st.showID();
	ResearchAssistant ra = new ResearchAssistant();
	ra.id = 3;
	ra.conductLecture();
	ra.showID();
}
}
