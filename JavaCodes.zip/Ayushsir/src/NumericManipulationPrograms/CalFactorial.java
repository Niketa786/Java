package NumericManipulationPrograms;

import java.util.Scanner;

//public class CalFactorial {
//public static void main(String[] args) {
//	Scanner scan = new Scanner(System.in);
//	System.out.println("Enter number: ");
//	int n = scan.nextInt();
//	int fact = 1;
//	for (int i=1; i <= n; i++) {
//		fact = fact * i;
//	}
//	System.out.println("Factorial of " + n + " is " + fact);
//}
//}


public class CalFactorial {
public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	System.out.println("Enter number: ");
	int n = scan.nextInt();
	int res = calFact(n);
	System.out.println("Factorial of "+ n + " is "+ res);
}
static int calFact(int n) {
	int fact = 1;
	for (int i=1; i <= n; i++) {
		fact = fact * i;
	}
	return fact;
}
}