package NumericManipulationPrograms;

import java.util.Scanner;

public class squareSum {
public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	System.out.println("enter number");
	int n = scan.nextInt();
	int sum = 0;
	for (int i = 1; i <= n; i++) {
		sum += i*i;
	}
	System.out.println("The sum of squares of the first " + n + " numbers is " + sum);
}
}
