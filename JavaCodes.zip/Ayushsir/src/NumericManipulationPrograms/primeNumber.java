package NumericManipulationPrograms;

import java.util.Scanner;

//public class primeNumber {
//public static void main(String[] args) {
//	Scanner scan = new Scanner(System.in);
//	System.out.println("Enter number: ");
//	int n = scan.nextInt();
//	int count = 0;
//	for (int i = 1; i <= n; i++) {
//		if (n%i == 0) {
//			count++;
//		}
//	}
//		if (count == 2) {
//			System.out.println(n + " is a prime number");
//		} else {
//			System.out.println(n + " is not a prime number");
//		}
//	}
//}

//public class primeNumber {
//public static void main(String[] args) {
//	Scanner scan = new Scanner(System.in);
//	System.out.println("Enter number: ");
//	int n = scan.nextInt();
//	int count = 0;
//	for (int i = 2; i < n; i++) {
//		if (n%i == 0) {
//			count++;
//		}
//	}
//		if (count == 0) {
//			System.out.println(n + " is a prime number");
//		} else {
//			System.out.println(n + " is not a prime number");
//		}
//	}
//}

//public class primeNumber {
//public static void main(String[] args) {
//	Scanner scan = new Scanner(System.in);
//	System.out.println("Enter number: ");
//	int n = scan.nextInt();
//	int count = 0;
//	for (int i = 2; i <= (int)Math.sqrt(n); i++) {
//		if (n%i == 0) {
//			count++;
//		}
//	}
//		if (count == 0) {
//			System.out.println(n + " is a prime number");
//		} else {
//			System.out.println(n + " is not a prime number");
//		}
//	}
//}

//public class primeNumber {
//public static void main(String[] args) {
//	Scanner scan = new Scanner(System.in);
//	System.out.println("Enter number: ");
//	int n = scan.nextInt();
//	if(n==1) {
//		System.out.println(n + " is not a prime number");
//	}else {
//	findPrime(n);
//	}
//}
//static void findPrime(int n) {
//	//check weather number is prime or not
//	int count = 0;
//	for (int i = 2; i <= Math.sqrt(n); i++) {
//		if (n%i == 0) {
//			count++;
//		}
//	}
//		if (count == 0) {
//			System.out.println(n + " is a prime number");
//		} else {
//			System.out.println(n + " is not a prime number");
//		}
//	}
//}

//prime number within range
public class primeNumber {
public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	System.out.println("Enter starting number: ");
	int start = scan.nextInt();
	System.out.println("Enter ending number: ");
	int end = scan.nextInt();
	if (start == 1) {
		start++;
	}
	for (int i = start; i <= end; i++) {
//		boolean status = findPrime(i);
//		if (status == true) {
		//OR
		if(findPrime(i)) {
			System.out.println(i);
		}
	}
}

static boolean findPrime(int n) {
//check weather number is prime or not
int count = 0;
for (int i = 2; i <= Math.sqrt(n); i++) {
	if (n%i == 0) {
		return false;
	}
}
	return true;
}
}












