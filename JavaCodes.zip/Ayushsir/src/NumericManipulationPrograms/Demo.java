package NumericManipulationPrograms;

import java.util.Scanner;

public class Demo {
public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	int N = scan.nextInt();
	
	if (N>0) {
		System.out.println(N + " is a Positive number.");
	}
	else if (N<0) {
		System.out.println(N + " is a Negative number.");
	}
	else {
		System.out.println(N + " is a Zero.");
	}
}
}
