package NumericManipulationPrograms;

import java.util.Scanner;

//convert decimal to binary
//public class Demo1 {
//public static void main(String[] args) {
//	Scanner scan = new Scanner(System.in);
//	int decimal = scan.nextInt();
//    String binary = decimalToBinary(decimal);
//    System.out.println("The binary equivalent of "+decimal+" is "+binary+".");
//	scan.close();
//}
//static String decimalToBinary(int decimal) {
//	 String binary = "";
//	 
//	 while(decimal > 0) {
//		 int rem = decimal % 2;
//		 binary = rem + binary;
//		 decimal = decimal / 2;
//	 }
//	 return binary;
//}
//}

//fibonacci series up to 10
//public class Demo1 {
//public static void main(String[] args) {
//	Scanner scan = new Scanner(System.in);
//	int  N = scan.nextInt();
//	int fib1 = 0;
//	int fib2 = 1;
//
//	while(fib1 <= N) {
//		System.out.print(fib1 + " ");
//		int fib3 = fib1 + fib2;
//		fib1 = fib2;
//		fib2 = fib3;
//		
//	}
//	scan.close();
//	}
//	}	

//check palindrome
//public class Demo1 {
//public static void main(String[] args) {
//	Scanner scan = new Scanner(System.in);
//	int  num = scan.nextInt();
//	int orgNum = num;
//	int rev = 0;
//	while (num > 0) {
//		int digit = num % 10;
//		rev = rev * 10 + digit;
//		num = num/10;
//	}
//	if (rev == orgNum) {
//		System.out.println("Palindrome");
//	} else {
//		System.out.println("not a Palindrome");
//	}
//}
//}
	
	
//single digit sum
//public class Demo1 {
//public static void main(String[] args) {
//	Scanner scan = new Scanner(System.in);
//	int  number = scan.nextInt();
//	int res = findSum(number);
//	while (res > 9) {
//		res = findSum(res);
//	}
//	System.out.println("The sigle-digit sum of digits of "+number+ " is "+ res+".");
//}
//
//static int findSum(int num) {
//	int sum = 0;
//	 while(num > 0) {
//		 int digit = num%10;
//		 sum += digit;
//		 num = num/10;
//	 }
//	 return sum;
//}
//}


//GDC(greatest common divisor)
//public class Demo1 {
//public static void main(String[] args) {
//	Scanner scan = new Scanner(System.in);
//	int  Num1 = scan.nextInt();
//	int  Num2 = scan.nextInt();
//	int res = findGcd(Num1, Num2);
//System.out.println("The " +Num1+ " & "+Num2+ " GCD is: " + res);
//}
//	static int findGcd(int num1, int num2) {
//	while (num2 != 0) {
//		int rem = num1 % num2;
//		num1 = num2;
//		num2 = rem;
//	}
//	return num1;
//}
//}

//	//Smallest digit
//	public static void main(String[] args) {
//		Scanner scan = new Scanner(System.in);
//		int  number = scan.nextInt();
//		int smallest = findSmallestDigit(number);
//	System.out.println("The smallest digit in this" +number+ " is: " + smallest);
//	scan.close();
//	}
//		static int findSmallestDigit(int num) {
//			int smallest = 9;
//			
//		while (num > 0) {
//			int digit = num % 10;
//			if (digit < smallest) {
//		     smallest = digit;
//		}
//			num /= 10;
//		}
//		return smallest;
//	}
//}

	
//	//PerfectSquare
//	public static void main(String[] args) {
//		Scanner scan = new Scanner(System.in);
//		int  number = scan.nextInt();
//		findPerfectSquare(number);
//	scan.close();
//	}
//		static int findPerfectSquare(int num) {
//			int root = (int)Math.sqrt(num);
//			
//			if((root * root)== num) {
//				System.out.println("PerfectSquare");
//		} else {
//			System.out.println(" not a PerfectSquare");
//		}
//		return root;
//	}
//}
	

	//public class AvgAndSwap {
//		public static void main(String[] args) {
//			Scanner scan = new Scanner(System.in);
//			int a = scan.nextInt();
//			int b = scan.nextInt();
//			int c = scan.nextInt();
//			
//			int sum = a + b + c;
//			
//			double Avg = sum / 3.0;
//			
//			System.out.println(Avg);
//		}
	//}


//	public class AvgAndSwap {
//		public static void main(String[] args) {
//			Scanner scan = new Scanner(System.in);
//			int a = scan.nextInt();
//			int b = scan.nextInt();
//			System.out.println("before swapping");
//			System.out.println("a= " + a + " b= " + b);
//			
//			a = a+b;
//			b = a-b;
//			a = a - b;
//			
//			System.out.println("before swapping");
//			System.out.println("a= " + a + " b= " + b);
//			
//		}
//	}
	
	//fahrengeit to celsius
//	public class FahrenheitToCelsius {
//		public static void main(String[] args) {
//			Scanner scan = new Scanner(System.in);
//			double fahrenheit = scan.nextDouble();
//			
//			double celsius = (fahrenheit - 32) * 5.0 / 9.0;
//			
//			System.out.println(celsius);
//		}
//		}	
	
//N prime numbers
//public class NprimeNumber {
//public static void main(String[] args) {
//	Scanner scan = new Scanner(System.in);
//	int number = scan.nextInt();
//	
//	for (int i  = 2; i <= number; i++) {
//		int count = 0;
////		for (int j  = 2; j <= i; j++) {
//		//OR
////		for (int j  = 2; j <= i/2; j++) {
//		//OR
//		for (int j  = 2; j < i; j++) {
//			if (i % j == 0) {
//				count++;
//			}
//		
//		}
//	
////		if (count == 2) {
//		//OR
//		if (count == 0) {
//			System.out.println(i);
//		} 
//	}
//	scan.close();
//}
//}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	





























		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	

