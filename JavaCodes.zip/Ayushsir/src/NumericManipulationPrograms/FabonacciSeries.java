package NumericManipulationPrograms;

import java.util.Scanner;

//public class FabonacciSeries {
//public static void main(String[] args) {
//	Scanner scan = new Scanner(System.in);
//	System.out.println("Enter Number: ");
//	int n = scan.nextInt();
//	int fib1 = 0;
//	int fib2 = 1;
//	
//	 System.out.print(fib1+ " " +fib2);
//	 
//	 for (int i = 1 ; i <= n-2; i++) {
//		int fib3 = fib1 + fib2;
//		System.out.print(" "+fib3 + " ");
//		fib1 = fib2;
//		fib2 = fib3;
//	 }
//}
//}

public class FabonacciSeries {
public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	System.out.println("Enter Number: ");
	int n = scan.nextInt();
	int fib1 = 0;
	int fib2 = 1;
	
	 System.out.print(fib1+ " " +fib2);
	 
	 for (int i = 3 ; i <= n; i++) {
		int fib3 = fib1 + fib2;
		System.out.print(" "+fib3 + " ");
		fib1 = fib2;
		fib2 = fib3;
	 }
}
}





























