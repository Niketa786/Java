package NumericManipulationPrograms;

import java.util.Scanner;

public class sumOfNatural {
		public static void main(String[] args) {
			Scanner scan = new Scanner(System.in);
			System.out.println("enter number");
			int n = scan.nextInt();
			int sum = 0;
			for (int i = 1; i <= n; i++) {
				sum += i;
			}
			System.out.println("The sum of first " + n + " natural numbers is " + sum);
		}
		}

