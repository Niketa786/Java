package NumericManipulationPrograms;

import java.util.Scanner;

//public class EvenOdd {
//	public static void main(String[] args) {
//		Scanner scan = new Scanner(System.in);
//		System.out.println("Enter number: ");
//		int n = scan.nextInt();
//		if (n % 2 == 0) {
//			System.out.println(n + " is a Even number");
//		} else {
//			System.out.println(n + " is a Odd number");
//		}
//	}
//}

//Odd sum program
//public class EvenOdd {
//	public static void main(String[] args) {
//		Scanner scan = new Scanner(System.in);
//		System.out.println("Enter number: ");
//		int n = scan.nextInt();
//		int sum = 0;
//		for (int i =1; i <= n; i++) {
//		if (i % 2 != 0) {
//			sum += i;
//		} 
//	}
//			System.out.println("The sum of a Odd number is: " + sum);
//		}
//	}

public class EvenOdd {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter number: ");
		int n = scan.nextInt();
		int sum = 0;
		for (int i =1; i <= n; i++) {
		if (i % 2 == 0) {
			sum += i;
		} 
	}
			System.out.println("The sum of a Even number is: " + sum);
		}
	}
























