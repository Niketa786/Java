package NumericManipulationPrograms;

import java.util.Scanner;

public class NthTermSeries {
public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	int n = scan.nextInt();
	
	int res = n * (n+1)/2;
	System.out.println("the " +n+ "th term of the series is " +res + ".");
}
}
