package NumericManipulationPrograms;

import java.util.Scanner;

public class reverseNumber {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("enter number");
		int n = scan.nextInt();
		int rev = 0;
		//find last digit of number
		//remove last digit og number
		while (n != 0) {
			int rem = n%10;
			rev = rev * 10 + rem; 
			n = n/10;
		}
		System.out.println("The reverse of " + n + " numbers is " + rev);
	}
}
