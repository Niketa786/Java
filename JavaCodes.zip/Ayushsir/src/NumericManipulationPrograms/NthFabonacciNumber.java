package NumericManipulationPrograms;

import java.util.Scanner;

public class NthFabonacciNumber {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter Number: ");
		int n = scan.nextInt();

		if (n == 0) {
			System.out.println("The 0th Fabonacci number is 0");
		}
		else if (n == 1) {
			System.out.println("The 1th Fabonacci number is 1");
		}
		else {
		 int a = 0;
		 int b = 1;
		 int fib = 0;
		 for (int i = 2 ; i <= n; i++) {
			fib = a + b;
			a = b;
			b = fib;
		 
		 }
		 System.out.println("The " + n + "th Fabonacci number is " + fib);
	
}
}
}
