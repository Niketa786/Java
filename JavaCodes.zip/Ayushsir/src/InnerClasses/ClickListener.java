package InnerClasses;

public interface ClickListener {
void onClick();
}


class Button {
	private String label;
	public Button(String label) {
		this.label = label;
	}
	
	public void click() {
		System.out.println("Clicking button '" + label + "'");
	}
	public void SetClickListener(ClickListener Listener) {
		Listener = new ClickListener() {
			public void onClick() {
				System.out.println("Button '" + label + "' was clicked!");
			}
		};
	}
}