package InnerClasses;

import InnerClasses.Program1.Program2;

public class ProgramMain {
public static void main(String[] args) {
	Program1 p1 = new Program1();
	p1.displayProgram1();
	Program1.Program2 p2 = p1.new Program2();
	p2.displayProgram2();
}
}
