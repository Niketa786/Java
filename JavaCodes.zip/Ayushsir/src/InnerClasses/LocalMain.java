package InnerClasses;

public class LocalMain {
public static void main(String[] args) {
	LocalProgram p1 = new LocalProgram();
	p1.displayProgram1();
	System.out.println("-------------");
    p1.myMethod();
}
}
