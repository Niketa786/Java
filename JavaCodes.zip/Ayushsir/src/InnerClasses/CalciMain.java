package InnerClasses;

public class CalciMain {
	public static void main(String[] args) {
int sum = Calculator.MathOperations.add(10, 5);
int diffrence = Calculator.MathOperations.sub(20, 7);
int product = Calculator.MathOperations.mul(4, 6);
int quotient = Calculator.MathOperations.div(15, 3);

System.out.println(sum);
System.out.println(diffrence);
System.out.println(product);
System.out.println(quotient);
}
}