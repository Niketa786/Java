package InnerClasses;

abstract  class Anonymous {
abstract void display1();
abstract void display2();
}
