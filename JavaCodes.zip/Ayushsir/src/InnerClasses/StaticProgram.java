package InnerClasses;

public class StaticProgram {
  static int a = 10; 

	static class StaticProgram2 {
		static int b = 20;
		
		static void displayProgram2() {
			System.out.println(a);
			System.out.println(b);
		}
	}
		void displayProgram1() {
			System.out.println(a);
		StaticProgram2.displayProgram2();
		}
}
