package InnerClasses;

public class AnonymousMain {
public static void main(String[] args) {
	Anonymous am = new Anonymous() {
	void display1() {
		System.out.println("Inside display1.");
	}
	void display2() {
		System.out.println("Inside display2.");
	}
};
am.display1();
am.display2();
}
}
