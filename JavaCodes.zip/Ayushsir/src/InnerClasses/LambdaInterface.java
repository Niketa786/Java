package InnerClasses;

@FunctionalInterface
//public interface LambdaInterface {
//void display();
//}


//public interface LambdaInterface {
//void display(int a);
//}

public interface LambdaInterface {
int add(int a, int b);
}