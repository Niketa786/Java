package InnerClasses;

public class ClickMain {
public static void main(String[] args) {
	Button submitButton = new Button("submit");
	
	submitButton.SetClickListener(new ClickListener() {
		public void onClick() {
			System.out.println("Submit button clicked!");
		}
	});
	submitButton.click();
}
}
