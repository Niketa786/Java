package InnerClasses;

public class MessagePrinter {
void printMessage(String message) {
	class Printer {
		void display() {
			System.out.println("Message: " + message);
		}
	}
	Printer print = new Printer();
	print.display();
}
}
