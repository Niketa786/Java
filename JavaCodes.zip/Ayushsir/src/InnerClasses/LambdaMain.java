package InnerClasses;

//public class LambdaMain {
//public static void main(String[] args) {
//	LambdaInterface p = () -> System.out.println("Inside display");
//	p.display();
//}
//}


//public class LambdaMain {
//public static void main(String[] args) {
//	LambdaInterface p = (a) -> {
//		System.out.println("Inside display");
//		System.out.println(a);
//	};
//	p.display(10);
//}
//}

public class LambdaMain {
public static void main(String[] args) {
	LambdaInterface p = (a,b) -> a + b;
	System.out.println(p.add(10,5));
}
}