package InnerClasses;

public class StaticMain {
	public static void main(String[] args) {
		StaticProgram p1 = new StaticProgram();
		p1.displayProgram1();
		StaticProgram.StaticProgram2.displayProgram2();
	}
}
