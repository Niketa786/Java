package InnerClasses;

public class Program1 {
int a = 10; 
class Program2 {
	int b = 20;
	
	void displayProgram2() {
		System.out.println(a);
		System.out.println(b);
	}
}
	void displayProgram1() {
		System.out.println(a);
	Program2 p2 = new Program2();
	p2.displayProgram2();
	}
}

