package InnerClasses;

public class PrintMain {
public static void main(String[] args) {
	MessagePrinter msg = new MessagePrinter();
	msg.printMessage("Hello, Local Class!");
}
}
