package InnerClasses;

import InnerClasses.Program1.Program2;

public class LocalProgram {
	int a = 10; 
	void myMethod() {
	class LocalProgram1 {
		static int b = 20;
		
		void displayProgram2() {
			System.out.println(a);
			System.out.println(b);
		}
	}
	LocalProgram1 lp = new LocalProgram1();
	lp.displayProgram2();
	}
	
	void displayProgram1() {
		System.out.println(a);
	}
}
