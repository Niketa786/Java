package Strings;

	import java.util.Scanner;
	import java.util.LinkedHashMap;
	import java.util.Map;
	
		public class ExtractStringDigit {
			    public static void main(String[] args) {
			        Scanner scanner = new Scanner(System.in);

			        String input = scanner.nextLine();

			        StringBuilder digits = new StringBuilder();

			        // Extract digits from the input string
			        for (int i = 0; i < input.length(); i++) {
			            char ch = input.charAt(i);
			            if (Character.isDigit(ch)) {
			                digits.append(ch);
			            }
			        }

			        // Print the extracted digits
			        System.out.println("Extracted Digits: " + digits.toString());

			        scanner.close();
			    }
			}
