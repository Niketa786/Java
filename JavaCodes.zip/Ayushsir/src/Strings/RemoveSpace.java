package Strings;

import java.util.Scanner;

//public class RemoveSpace {
//	    public static void main(String[] args) {
//	        Scanner scanner = new Scanner(System.in);
//
//	        // Ask the user to input a string
//
//	        String original = scanner.nextLine();
//
//	        // Remove all whitespace characters from the string
//	        String modified = original.replaceAll("\\s+", "");
//
//	        // Print both the original and modified strings
//	        System.out.println("Original String: " + original);
//	        System.out.println("Modified String: " + modified);
//
//	        scanner.close();
//	    }
//	}

public class RemoveSpace {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Ask the user to input a string
        String str = scanner.nextLine();
        String strArr[] = str.split(" ");
        String resStr = String.join("", strArr);

       

        // Print both the original and modified strings
        System.out.println("Original String: " + str);
        System.out.println("Modified String: " + resStr);

        scanner.close();
    }
}