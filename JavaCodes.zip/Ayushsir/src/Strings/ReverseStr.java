package Strings;

import java.util.Scanner;

//public class ReverseStr {
//public static void main(String[] args) {
//	Scanner scan = new Scanner(System.in);
//	System.out.println("Enter String: ");
//	String str = scan.next();
//	
//	char[] arr = str.toCharArray();
//	char[] revArr = new char[arr.length];
//	int j = revArr.length-1;
//	
//	for(int i = 0; i <= arr.length-1; i++) {
//		revArr[j] = arr[i];
//		j--;
//	}
//	
//	String revStr = new String(revArr);
//	
//	if (str.equals(revStr)) {
//		System.out.println(str + " is Palindrome.");
//	} 
//	else {
//		System.out.println(str + " is not Palindrome.");
//	}
//}
//}


//public class ReverseStr {
//public static void main(String[] args) {
//	Scanner scan = new Scanner(System.in);
//	System.out.println("Enter String: ");
//	String str = scan.next();
//	
//	int left = 0;
//	int right = str.length()-1;
//	
//	while (left < right) {
//		if ((str.charAt(left)) != (str.charAt(right))) {
//			System.out.println(str + " is not Palindrome.");
//			return;
//		} 
//		left++;
//		right--;
//	}
//	System.out.println(str + " is Palindrome.");
//}
//}



public class ReverseStr {
public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	String inputString = scan.nextLine();
	StringBuilder StringBuilder = new StringBuilder(inputString);
	String reversedString = StringBuilder.reverse().toString();
	System.out.println(reversedString);
	 scan.close();
}
}






































