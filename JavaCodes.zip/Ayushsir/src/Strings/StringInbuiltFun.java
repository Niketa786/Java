package Strings;

public class StringInbuiltFun {
	public static void main(String[] args) {
		String str = "Welcome Niketa";
		System.out.println(str);
		System.out.println(str.toUpperCase());   //WELCOME NIKETA
		System.out.println(str.toLowerCase());   //welcome niketa
		System.out.println(str.length());        //14
		System.out.println(str.contains("Niketa"));  //true
		System.out.println(str.startsWith("kod"));   //false
		System.out.println(str.startsWith("wel"));   //true
		System.out.println(str.endsWith("keta"));    //true
		System.out.println(str.charAt(5));           //m
		System.out.println(str.indexOf("i"));        //9
		System.out.println(str.indexOf("e"));        //1
		System.out.println(str.lastIndexOf("e"));    //11
		System.out.println(str.isEmpty());           //false
		System.out.println(str.substring(3, 12));     //come Nike
		System.out.println(str.substring(3));         //come Niketa
		
		String str1 = "         HI    Ni keta       ";
		System.out.println(str1.trim());               //HI    Ni   keta(it removes starting and ending space but not in between
		
		System.out.println(str.replace('N', 'T'));     // Welcome Tiketa
		
		String data = "apple,banana,grapes";
		String[] fruits = data.split(",");           //converts Strings into String type array
		for(int i = 0; i < fruits.length; i++) {        //apple
			System.out.println(fruits[i]);               //banana
			                                             //grapes
		}
	    
		String Word = "Hello";                            
		char[] arr = Word.toCharArray();                  //H
		                                                  //e
		for(int i = 0; i <= arr.length-1; i++) {          //l
			System.out.println(arr[i]);                   //l
		}                                                 //0
		
	}	
}
