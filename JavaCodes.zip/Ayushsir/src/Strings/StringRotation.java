package Strings;

import java.util.Scanner;

public class StringRotation {
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);

	        String s1 = scanner.nextLine();

	        String s2 = scanner.nextLine();

	        if (isRotation(s1, s2)) {
	            System.out.println("The string '" + s2 + "' is a rotation of '" + s1 + "'.");
	        } else {
	            System.out.println("The string '" + s2 + "' is NOT a rotation of '" + s1 + "'.");
	        }

	        scanner.close();
	    }

	    public static boolean isRotation(String s1, String s2) {
	        // Check length first
	        if (s1.length() != s2.length()) {
	            return false;
	        }
	        // Concatenate s1 with itself and check if s2 is a substring
	        String combined = s1 + s1;
	        return combined.contains(s2);
	    }
	}