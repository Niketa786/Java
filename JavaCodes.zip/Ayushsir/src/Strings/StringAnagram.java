package Strings;

import java.util.Scanner;
import java.util.Arrays;

public class StringAnagram {
public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	System.out.println("Enter Strings: ");
	String s1 = scan.next();
	String s2 = scan.next();
	
	char arr1[] = s1.toCharArray();
	char arr2[] = s2.toCharArray();
	
	Arrays.sort(arr1);
	Arrays.sort(arr2);
	
	String sortedStr1 = new String(arr1);
	String sortedStr2 = new String(arr2);
	
    System.out.println(sortedStr1.equals(sortedStr2)); 
    scan.close();
}
}
