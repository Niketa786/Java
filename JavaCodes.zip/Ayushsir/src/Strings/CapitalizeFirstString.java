package Strings;

import java.util.Scanner;
public class CapitalizeFirstString {

	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);

	        String sentence = scanner.nextLine();

	        // Split the sentence into words
	        String[] words = sentence.split(" ");

	        StringBuilder capitalizedSentence = new StringBuilder();

	        // Capitalize the first letter of each word and add to StringBuilder
	        for (String word : words) {
	            if (word.length() > 0) {
	                String capitalizedWord = word.substring(0, 1).toUpperCase() +
	                                         word.substring(1).toLowerCase();
	                capitalizedSentence.append(capitalizedWord).append(" ");
	            }
	        }

	        // Trim trailing space and print result
	        System.out.println(capitalizedSentence.toString().trim());
	    }
	}
