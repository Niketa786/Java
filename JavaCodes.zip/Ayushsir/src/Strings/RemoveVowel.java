package Strings;

import java.util.Scanner;

public class RemoveVowel {

	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);

	        // Read input string

	        String input = scanner.nextLine();

	        // Initialize a StringBuilder to build the result without vowels
	        StringBuilder result = new StringBuilder();

	        // Iterate through each character in the input string
	        for (int i = 0; i < input.length(); i++) {
	            char ch = input.charAt(i);

	            // Check if the character is NOT a vowel (both lowercase and uppercase)
	            if (!isVowel(ch)) {
	                result.append(ch);
	            }
	        }

	        // Print the result string without vowels
	        System.out.println(result.toString());

	        scanner.close();
	    }

	    // Helper method to check if a character is a vowel
	    private static boolean isVowel(char ch) {
	        ch = Character.toLowerCase(ch);
	        return (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u');
	    }
	}