package Strings;

import java.util.Scanner;

public class CountVowels {
public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	String str = scan.nextLine();
	
	int count = 0;
	
	for (int i = 0; i <= str.length()-1; i++) {
		char ch = str.charAt(i);
		if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u' || ch == 'A' || ch == 'E' || ch == 'I' || ch == 'O' || ch == 'U') {
			count++;
		}
	}
	System.out.println(str);
	System.out.println(count);
}
}
