package Strings;

import java.util.Scanner;
import java.util.regex.Pattern;

public class RegexPatternValidator {
public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	String str = scan.next();
	
	try {
		Pattern.compile(str);
		System.out.println("The pattern'" + str + "'is valid.");
	} 
	catch(Exception e) {
		System.out.println("The pattern'" + str + "'is not valid.");
	}
	scan.close();
}
}
