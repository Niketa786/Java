package Strings;

import java.util.Scanner;

public class TripleTransformation {
public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	String word1 = scan.next();
	String word2 = scan.next();
	String word3 = scan.next();
	
	String newWord1 = word1.replaceAll("[AEIOUaeiou]", "%");
	String newWord2 = word2.replaceAll("[AEIOUaeiou]", "#");
	String newWord3 = word3.toUpperCase();
	
	String res = newWord1 + newWord2 + newWord3;
	System.out.println(res);
	
	scan.close();
}
}
