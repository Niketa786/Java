package Strings;

import java.util.Scanner;

public class CountCharStr {

public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    
    System.out.println("Enter string:");
    String input = scan.nextLine();
    
    System.out.println("Enter character to count:");
    // charAt(0) gets the first character of the next line entered
    char ch = scan.next().charAt(0); 

    int count = 0;
    // Fix: Use < instead of <= to stay within bounds
    for (int i = 0; i < input.length(); i++) {
        if (input.charAt(i) == ch) {
            count++;
        }
    }

    System.out.println("Original String: " + input);
    System.out.println("Character: " + ch);
    System.out.println("Occurrences: " + count);
    
    scan.close();
}
}