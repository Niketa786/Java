package Strings;

public class MutableString {
	public static void main(String[] args) {
		StringBuffer sb = new StringBuffer();
		System.out.println(sb.capacity());//16
		sb.append("java");
		System.out.println(sb);
		System.out.println(sb.capacity());//16
		sb.append("is a programming language");
		System.out.println(sb);
		System.out.println(sb.capacity());//34
		
		StringBuilder sbuild = new StringBuilder();
		System.out.println(sbuild.capacity()); //16
	}
}
