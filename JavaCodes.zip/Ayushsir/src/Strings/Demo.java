package Strings;

public class Demo {
public static void main(String[] args) {
	String s1 = "java";
	String s2 = new String("JAVA");
	
	if(s1 == s2) {
		System.out.println("References are equal.");
	}
	else {
		System.out.println("References are not equal.");
	}
	
	if(s1.equals(s2)) {
		System.out.println("Values are equal.");
	}
	else {
		System.out.println("Values are not equal.");
	}
	
	if(s1.equalsIgnoreCase(s2)) {
		System.out.println("Values are equal after ignoring the cases.");
	}
	else {
		System.out.println("Values are not equal after ignoring the cases.");
	}
}
}
