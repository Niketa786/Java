package Strings;

import java.util.Scanner;

public class AsciiOfCharacter {
public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	char ch = scan.next().charAt(0);
	
	int asciiVal = ch;
	System.out.println("the ASCII value of '" + ch +" 'is: " +asciiVal);
	
	scan.close();
}
}
