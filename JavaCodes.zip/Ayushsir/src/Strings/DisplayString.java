package Strings;

import java.util.Scanner;

public class DisplayString {
public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	System.out.println("enter the line of text: ");
	String input = scan.nextLine();
	
	String str1 = input;
	String str2 = new String(input);
	
	System.out.println("String created using double quotes: " + str1);
	System.out.println("String created using new Keyword: " + str2);
	
	//compare references
	System.out.println("Are the two Strings equal by '==' ?" + (str1 == str2));
	
	//compare contents
		System.out.println("Are the two Strings equal by 'equals()'?" + str1.equals(str2));
}
}
