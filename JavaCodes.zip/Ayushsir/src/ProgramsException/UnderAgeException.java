package ProgramsException;

// This matches the filename: UnderAgeException.java
public class UnderAgeException extends Exception {
    UnderAgeException() {
        super("You are too young. Go and see cartoons.");
    }
}

// Remove "public" from this one
class OverAgeException extends Exception {
    OverAgeException() {
        super("You are too old. Take rest.");
    }
}