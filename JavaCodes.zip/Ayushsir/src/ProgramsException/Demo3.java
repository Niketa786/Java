package ProgramsException;
import java.util.Scanner;

//Handling multiple Exception with generic Catch Blocks
public class Demo3 {
public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	int n = 0;
	// Get the number of elements store in the array
	try {
		n = Integer.parseInt(scan.nextLine());
		if (n < 1 || n > 100) {
			System.out.println("The number of elements must be between 1 to 100.");
			return;
		}
	} catch (NumberFormatException e) {
		System.out.println("Invalid input! please enter an integer for the number of elements.");
		return;
	} 
	int[] numbers = new int[n];
	//Read n integers from user input
	for (int i = 0; i < n; i++) {
		try {
			numbers[i] = Integer.parseInt(scan.nextLine());
		} catch (NumberFormatException e) {
			System.out.println("Invalid input! please enter integers only.");
			System.out.println("An unexpected error occurred.");
			System.out.println("Numbers entered successfully.");
			return;
		} catch (ArrayIndexOutOfBoundsException e) {
			return;
		} catch (Exception e) {
			return;
		}
	}
	System.out.println("Numbers entered successfully.");
	scan.close();
}
}
