package ProgramsException;
import java.util.Scanner;

public class Demo1 {
public static void main(String[] args) {
	
	try {
		System.out.println("Enter size of array");
		Scanner scan = new Scanner(System.in);
		int size = scan.nextInt();
		int[] arr = new int[size];
		System.out.println("enter the element to be stored in array");
		int element = scan.nextInt();
		System.out.println("Enter an index at which element should be stored");
		int index = scan.nextInt();
		arr[index] = element;
		System.out.println("Element has been stored in array");
 	}
	catch (Exception e) {
		System.out.println("Exception is handled");
	}
	System.out.println("Connection is terminated");
}
}
