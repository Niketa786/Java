package ProgramsException;

public class Main {
public static void main(String[] args) {
	DrivingLicense d1 = new DrivingLicense();
	d1.takeUserAge();
	try {
		d1.verify();
	} 
	catch (UnderAgeException e) {
		e.printStackTrace();
	} 
	catch (OverAgeException e) {
		e.printStackTrace();
	}
}
}
