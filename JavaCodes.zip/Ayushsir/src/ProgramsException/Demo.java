package ProgramsException;
import java.util.Scanner;

public class Demo {
public static void main(String[] args) {
	try {
		System.out.println("Connection is established.");
		Scanner scan = new Scanner(System.in);
		System.out.println("enter a numerator");
		int numerator = scan.nextInt();
		System.out.println("enter a denominator");
		int denominator = scan.nextInt();
		int result = numerator / denominator;
		System.out.println(result);
	} catch (Exception e) {
		System.out.println("Exception is handled.");
		
	}
	System.out.println("Connection is terminated.");
}
}
