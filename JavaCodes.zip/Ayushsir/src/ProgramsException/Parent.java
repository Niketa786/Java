package ProgramsException;

//Managing the Exception in Inherited classes

//Rule-1:  if parent class method is throwing an exception then child class Overriden method can choose not to throw Exception 
//public class Parent {
//void display() throws Exception {
//	System.out.println("Inside parent display.");
//}
//}
//
//class Child extends Parent {
//	@Override
//	void display() {
//		System.out.println("Inside child display");
//	}
//}


////Rule-2:  if parent class method is throwing an exception then child class Overriden method can choose to throw Exception 
//public class Parent {
//void display() throws Exception {
//	System.out.println("Inside parent display.");
//}
//}
//
//class Child extends Parent {
//	@Override
//	void display() throws Exception{
//		System.out.println("Inside child display");
//	}
//}

////Rule-3:  if parent class method is not throwing an exception then child class Overriden method cannot throw Exception 
//public class Parent {
//void display() {
//	System.out.println("Inside parent display.");
//}
//}
//
//class Child extends Parent {
//	@Override
//	void display() throws Exception {             // ------> error
//		System.out.println("Inside child display");
//	}
//}

//Rule-4:  if parent class method is throwing an exception then child class Overriden method can decide to throw D/R Exception. Provided than child method exception 
//is child of parent method exception
//public class Parent {
//void display() throws Exception {
//	System.out.println("Inside parent display.");
//}
//}
//
//class Child extends Parent {
//	@Override
//	void display() throws ArithmeticException {            
//		System.out.println("Inside child display");
//	}
//}

//public class Parent {
//void display() throws RuntimeException {
//	System.out.println("Inside parent display.");
//}
//}
//
//class Child extends Parent {
//	@Override
//	void display() throws ArithmeticException {            
//		System.out.println("Inside child display");
//	}
//}


//Rule-5:  if parent class method is throwing an exception then child class Overriden method can decide to throw D/R Exception. which is not a parent-child relationship, 
//but it is possible if both exceptions are of RuntimeException
//public class Parent {
//void display() throws ArithmeticException {
//	System.out.println("Inside parent display.");
//}
//}
//
//class Child extends Parent {
//	@Override
//	void display() throws RuntimeException {            
//		System.out.println("Inside child display");
//	}
//}

//public class Parent {
//void display() throws ArithmeticException {
//	System.out.println("Inside parent display.");
//}
//}
//
//class Child extends Parent {
//	@Override
//	void display() throws ArrayIndexOutOfBoundsException {            
//		System.out.println("Inside child display");
//	}
//}


//import java.io.IOException;
//public class Parent {
//void display() throws IOException {
//	System.out.println("Inside parent display.");
//}
//}
//
//class Child extends Parent {
//	@Override
//	void display() throws InterruptedException {          //----error   
//		System.out.println("Inside child display");
//	}
//}


//Rule-5:  child class method can throw same exception  or smaller Exception(child Exception). but it cannot throw larger exception(parent exception)
import java.io.IOException;
public class Parent {
void display() throws IOException {
	System.out.println("Inside parent display.");
}
}

class Child extends Parent {
	@Override
	void display() throws Exception {          //---------error        
		System.out.println("Inside child display");
	}
}








































































































































































































































































































































































































































































