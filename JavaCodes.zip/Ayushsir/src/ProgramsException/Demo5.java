package ProgramsException;
import java.util.Scanner;

public class Demo5 {
public static void main(String[] args) {
	System.out.println("Main method execution started");
	divide();
	System.out.println("Main method execution Completed");
}

static void divide() {
	try {
		System.out.println("Division started.");
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter numerator");
		int a = scan.nextInt();
		System.out.println("Enter Denominator");
		int b = scan.nextInt();
		int res = a/b;
		System.out.println(res);
	} 
	catch (Exception e) {
		System.out.println("Exception is handled in divide method");
	}
	System.out.println("Division completed");
}
}
