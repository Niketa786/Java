package ProgramsException;

public class Demo4 {
public static void main(String[] args) {
	for (int i = 1; i <= 5; i++) {
		System.out.println(i);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
}
