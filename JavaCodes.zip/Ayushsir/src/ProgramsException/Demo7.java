package ProgramsException;

import java.util.Scanner;

//Ducking the exception
public class Demo7 {
	public static void main(String[] args) {
		System.out.println("Main method execution started");
		try {
		divide(); 
		}
		catch (Exception e) {
		System.out.println("Exception handled in main method.");
	}
		System.out.println("Main method execution completed");
	}
	
	static void divide()  throws Exception {
			Scanner scan = new Scanner(System.in);
			System.out.println("Enter numerator");
			int a = scan.nextInt();
			System.out.println("Enter Denominator");
			int b = scan.nextInt();
			int res = a/b;
			System.out.println(res);
	}
}
