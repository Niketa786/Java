package ProgramsException;
import java.util.Scanner;


// Using throw and throws
public class Demo6 {
    
    public static void main(String[] args) {
        System.out.println("Main method execution started");
        try {
            divide();
        } catch (Exception e) {
            System.out.println("Exception is handled in main method");
        }
        System.out.println("Main method execution ended");
    }
	
    // Method must be outside of main and marked static
    static void divide() throws Exception {
        try {
            System.out.println("Division started");
            Scanner scan = new Scanner(System.in);
            System.out.println("Enter numerator");
            int a = scan.nextInt();
            System.out.println("Enter denominator");
            int b = scan.nextInt();
            
            int res = a / b;   // Potential ArithmeticException
            System.out.println("Result: " + res);
            
        } catch (Exception e) {
            System.out.println("Exception is handled in divide method");
            throw e; // Re-throwing the exception to main
        } finally {
            System.out.println("Division completed (finally block executed)");
        }
    }
}
