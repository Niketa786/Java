package ProgramsException;
import java.util.Scanner;


public class DrivingLicense {
int age;

void takeUserAge() {
	Scanner scan = new Scanner(System.in);
	System.out.println("Enter your age: ");
	age = scan.nextInt();
}

void verify() throws UnderAgeException, OverAgeException{
	if (age < 18) {
		UnderAgeException uae = new UnderAgeException();
		throw uae;
		//OR
//		throw new UnderAgeException();
	}
	else if (age > 65) {
		OverAgeException uae = new OverAgeException();
		throw uae;
		//OR
//		throw new OverAgeException();
	} 
	else {
		System.out.println("Driving License issued.");
	}
}
}