package Oops;

public class MethodInheritanceMain {
public static void main(String[] args) {
	Child2 ch = new Child2();
	ch.display1();
	ch.display2();
	ch.display3();
}
}
