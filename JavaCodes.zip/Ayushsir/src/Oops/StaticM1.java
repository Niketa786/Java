//package Oops;
//
//import java.util.Scanner;
//
//public class StaticM1 {
//
//	public static void main(String[] args) {
//		Scanner scan = new Scanner(System.in);
//		String operation = scan.next();
//		int a = scan.nextInt();
//		int b = scan.nextInt();
//		
//		switch(operation) {
//		case "Addition": 
//			int addres = Math.add(a, b);
//			System.out.println(addres);
//			break;
//			
//		case "Subtraction": 
//			int subres = Math.sub(a, b);
//			System.out.println(subres);
//			break;
//			
//		case "Multiplication": 
//			int mulres = Math.mul(a, b);
//			System.out.println(mulres);
//			break;
//			
//		case "Division": 
//			int divres = Math.div(a, b);
//			System.out.println(divres);
//			break;
//		}
//	}
//}
