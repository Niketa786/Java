package Oops;

public class Professors1 {
	public static void main(String[] args) {
		
		Professors p1 = new Professors();
		p1.id = 1;
		p1.name = "Harish Pathak";
		p1.dept = "computer science";
		p1.yearOfExperience = 10;
		System.out.println("Professors Id: " + p1.id);
		System.out.println("Professors Name: " + p1.name);
		System.out.println("Department: " + p1.dept);
		System.out.println("yearOfExperience: " + p1.yearOfExperience);
		
		p1.conductLecture();
		p1.provideFeedback();
}
}