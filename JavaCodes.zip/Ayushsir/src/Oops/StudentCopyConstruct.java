package Oops;

public class StudentCopyConstruct {
int rollNo;
String name;

StudentCopyConstruct(int rollNo, String name) {
	this.rollNo = rollNo;
	this.name = name;
}

StudentCopyConstruct(StudentCopyConstruct ref) {
	rollNo = ref.rollNo;
	name = ref.name;
}

public void Display() {
	System.out.println("Roll No: " + rollNo);
	System.out.println("Name: " + name);
}
}
