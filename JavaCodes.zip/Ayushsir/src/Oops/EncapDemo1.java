package Oops;

public class EncapDemo1 {
public static void main(String[] args) {
	EncapsulationDemo book = new EncapsulationDemo();
	book.setData(-20);
	book.getData();
}
}
