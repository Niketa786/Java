package Oops;

//public class StaticB1 {
//public static void main(String[] args) {
//	System.out.println(StaticBlocks.display());
//}
//}

public class StaticB1 {
public static void main(String[] args) {
	StaticBlocks.display();
}
}
