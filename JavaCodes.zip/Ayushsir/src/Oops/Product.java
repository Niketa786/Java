package Oops;

public class Product {
String productName;
double productPrice;
String productCategory;

Product(String productName, double productPrice, String productCategory) {
	this.productName = productName;
	this.productPrice = productPrice;
	this.productCategory = productCategory;
}

public void DisplayDetails() {
	System.out.println("ProductName: " + productName);
	System.out.println("ProductPrice: " + productPrice);
	System.out.println("ProductCategory: " + productCategory);
}
}
