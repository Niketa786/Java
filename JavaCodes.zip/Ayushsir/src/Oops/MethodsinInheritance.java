package Oops;

public class MethodsinInheritance {
 void display1() {
	 System.out.println("inside parent display1.");
 }
 
 void display2() {
	 System.out.println("inside parent display2.");
 }
}

class Child2 extends MethodsinInheritance {
	//inherited method -> display1()
	
	//overridden method
	@Override
	void display2() {
		System.out.println("inside child display2.");
	}
	
	//child specific method
	void display3() {
		System.out.println("inside child display3.");
	}
}