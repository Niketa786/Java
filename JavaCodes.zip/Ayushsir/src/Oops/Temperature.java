package Oops;

public class Temperature {

	private double celsius;
	
	public double getCelsius() {
		return celsius;
	}
	
	public void setCelsius(double cel) {
		celsius = cel;
	}
	
	public double getFahrenheit() {
		return (celsius * 9/5 + 32);
	}
}
