package Oops;

public class ProductMain {
public static void main(String[] args) {
	Product p1 = new Product("Laptop", 1200.50, "Electronics");
	Product p2 = new Product("Chair", 150.75, "Furniture");
	Product p3 = new Product("Book", 25.00, "Education");
	
	p1.DisplayDetails();
	p2.DisplayDetails();
	p3.DisplayDetails();
}
}
