package Oops;

public class Professors {
	int id;
	String name;
	String dept;
	int yearOfExperience;

	public void conductLecture() {
		System.out.println(name + " is conducting lecture.");
	}
	public void provideFeedback() {
		System.out.println(name + " is providing feedback.");
	}
}
