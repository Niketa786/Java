package Oops;

public class Notification {
String message;
int repeatCount;
boolean hasCustomMessage;

Notification() {
	message = "No new notification";
	repeatCount = 0;
	hasCustomMessage = false;
}
Notification(String message) {
	this.message = message;
	repeatCount = 0;
	hasCustomMessage = true;
}

Notification(String message, int repeatCount) {
	this.message = message;
	this.repeatCount = repeatCount;
	hasCustomMessage = true;
}

public void DisplayNotification() {
	System.out.println("Notification: " + message);
	if (repeatCount > 0) {
		System.out.println("Repeat Count: " + repeatCount);
	}
	System.out.println(hasCustomMessage);
}
}
