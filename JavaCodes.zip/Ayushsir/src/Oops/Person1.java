package Oops;

public class Person1 {
public static void main(String[] args) {
	
	Person p1 = new Person();
	p1.age = 23;
	p1.name = "Niketa";
	p1.emailId = "niketasanghnayak@gmail.com";
	System.out.println(p1.age);
	System.out.println(p1.name);
	System.out.println(p1.emailId);
	p1.sleep();
	p1.work();
	
	Person p2 = new Person();
	p2.age = 22;
	p2.name = "Sahana";
	p2.emailId = "sahana@gmail.com";
	System.out.println(p2.age);
	System.out.println(p2.name);
	System.out.println(p2.emailId);
	p2.sleep();
	p2.work();
}
}
