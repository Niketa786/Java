package Oops;

public class EncapsulationDemo {

	private int pageNo;
	
	void setData(int x) {
		if (x >= 0) {
		pageNo = x;
	}
		else {
		System.out.println("wrong data");
	}
	}
	void getData() {
		System.out.println(pageNo);
	}
}
