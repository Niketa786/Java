package Oops;

public class TemperatureMain {
public static void main(String[] args) {
	Temperature temp1 = new Temperature();
	temp1.setCelsius(25.0);
	System.out.println(temp1.getCelsius());
	System.out.println(temp1.getFahrenheit());
	Temperature temp2 = new Temperature();
	temp2.setCelsius(30.0);
	System.out.println(temp2.getCelsius());
	System.out.println(temp2.getFahrenheit());
}
}
