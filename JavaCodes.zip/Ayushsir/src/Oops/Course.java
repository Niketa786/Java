package Oops;

public class Course {
String courseName;
int enrollmentLimit;
String courseCode;
 public Course(String courseName) {
	 this(courseName, "UNSET", 100);
 }
 
 public Course(String courseName, String courseCode) {
	 this(courseName, courseCode, 100);
	 }
 

public Course(String courseName, String courseCode, int enrollmentLimit) {
	this.courseName = courseName;
	this.courseCode = courseCode;
	this.enrollmentLimit = enrollmentLimit;
}

public void displayInfo() {
	System.out.println("Course Name: " + courseName);
	System.out.println("Course code: " + courseCode);
	System.out.println("enrollmentLimit: " + enrollmentLimit);
}
}

























































