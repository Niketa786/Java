package Oops;

public class Student {
 private int rollNo;
 private String name;
 private int age;
 
// public void setDisplayrollNo (int x) {
//	 rollNo = x;
// }
// 
// public void setDisplayName (String Name) {
//	 name = Name;
// }
// 
// public void setDisplayPercentage (double y) {
//	 Percentage = y;
// }
 
 public void setDisplay(int x, String Name, int y) {
	 rollNo = x;
	 name = Name;
	 if (y > 0) {
		 age = y;
	 } else {
		 System.out.println("Invalid age. Age must be positive");
	 }
 }
 
// public void getDisplayrollNo() {
//	 System.out.println(rollNo);
// }
// 
// public void getDisplayroName () {
//	 System.out.println(name);
// }
// 
// public void getDisplayPercentage () {
//	 System.out.println(Percentage);
// }
 
 public int getRollNo() {
	 return rollNo;
 }
 
 public String getName() {
	 return name;
 }
 
 public int getAge() {
	 return age;
 }
 
}
