package Oops;

//public class StaticMethod {
//
//	static int add(int a, int b) {
//		return a + b;
//	}
//	
//	static int sub(int a, int b) {
//		return a - b;
//	}
//	
//	static int mul(int a, int b) {
//		return a * b;
//	}
//	
//	static int div(int a, int b) {
//		return a / b;
//	}
//	
//}



























































