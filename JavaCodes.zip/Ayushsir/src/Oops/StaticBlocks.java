package Oops;

//public class StaticBlocks {
//static int a;
//
//static {
//	a = 1024;
//}
//
//static String display() {
//	return "configuration setting is: " + a;
//}
//}


public class StaticBlocks {
static String url;
static String username;
static String password;

static {
	url = "jdbc:mysql://localhost:3306/mydatabse";
	username = "admin";
	password = "password123";
}

static void display() {
	System.out.println("Database URL: " + url);
	System.out.println("Username: " + username);
	System.out.println("Password : " + password);
}
}
