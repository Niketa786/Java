package Oops;

public class RectangleMain {
public static void main(String[] args) {
	Rectangle rect = new Rectangle();
	rect.setLength(5.0);
	rect.setWidth(3.0);
	System.out.println(rect.getLength());
	System.out.println(rect.getWidth());
	System.out.println(rect.CalculateArea());
}
}
