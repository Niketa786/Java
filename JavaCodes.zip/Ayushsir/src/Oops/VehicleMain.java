package Oops;

public class VehicleMain {
public static void main(String[] args) {
	Car myCar = new Car("Toyota", "Corolla", 2021, 5);
	Truck myTruck = new Truck("Ford", "F-150", 2019, 1.2);
	
	myCar.DisplayDetails();
	myTruck.DisplayDetails();
}
}
