package Oops;

public class DealerShip {
		public static void main(String[] args) {
			//This will invoke the Motor constructor
			Motor mt = new Motor("Tesla Model S");
		}
	}

