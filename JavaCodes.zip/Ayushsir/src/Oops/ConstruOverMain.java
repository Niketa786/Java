package Oops;

public class ConstruOverMain {
public static void main(String[] args) {
	ConstructorOverloading c1 = new ConstructorOverloading();
	c1.Display();
	ConstructorOverloading c2 = new ConstructorOverloading(12, "Ravi");
	c2.Display();
	ConstructorOverloading c3 = new ConstructorOverloading(13);
	c3.Display();
	ConstructorOverloading c4 = new ConstructorOverloading("anuj");
	c4.Display();
	
}
}
