package Oops;

public class NotificationMain {
public static void main(String[] args) {
	Notification N1 = new Notification();
	Notification N2 = new Notification("Meeting at 10 AM");
	Notification N3 = new Notification("Submit report" , 2);
	
	N1.DisplayNotification();
	N2.DisplayNotification();
	N3.DisplayNotification();
	
}
}
