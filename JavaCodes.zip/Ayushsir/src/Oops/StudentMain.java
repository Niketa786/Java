package Oops;

public class StudentMain {
public static void main(String[] args) {
	Student s1 = new Student();
//	s1.setDisplayrollNo(9);
//	s1.setDisplayName("Niketa");
//	s1.setDisplayPercentage(91.52);
	s1.setDisplay(10, "Kunjali", 25);
//	s1.getDisplayrollNo();
//	s1.getDisplayroName();
//	s1.getDisplayPercentage();
	System.out.println(s1.getRollNo());
	System.out.println(s1.getName());
	System.out.println(s1.getAge());
}
}
