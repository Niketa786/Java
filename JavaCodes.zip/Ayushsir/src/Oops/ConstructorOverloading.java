package Oops;

public class ConstructorOverloading {
int roll;
String name;


public void Display() {
	System.out.println(roll);
	System.out.println(name); 
}

ConstructorOverloading() {
	roll = 11;
	name = "amit";
}

ConstructorOverloading(int roll, String name) {
	this.roll = roll;
	this.name = name;
}

ConstructorOverloading(int roll) {
	this.roll = roll;
	name = "Sanjay";
}

ConstructorOverloading(String name) {
	roll = 14;
	this.name = name;
}

}
