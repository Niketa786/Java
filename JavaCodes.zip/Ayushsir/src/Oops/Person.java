package Oops;

public class Person {
int age;
String name;
String emailId;

void sleep() {
	System.out.println("person is sleeping");
}
void work() {
	System.out.println("person is working");
}
}

