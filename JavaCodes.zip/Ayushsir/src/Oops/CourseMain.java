package Oops;

public class CourseMain {
public static void main(String[] args) {
	Course course1 = new Course("Introduction to JAVA");
	Course course2 = new Course("Advance JAVA", "JAVA102");
	Course course3 = new Course("Data Structures", "COMPSCI303", 30);
	
	course1.displayInfo();
	course2.displayInfo();
	course3.displayInfo();
}
}
