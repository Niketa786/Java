package Oops;

public class Vehicle {
String make;
String model;
int year;

public Vehicle(String make, String model, int year) {
	this.make = make;
	this.model = model;
	this.year = year;
}
}

class Car extends Vehicle {
	int seatingCapacity;
	
	public Car (String make, String model, int year, int seatingCapacity) {
		super(make, model, year);
		this.seatingCapacity = seatingCapacity;
	}

public void DisplayDetails() {
	System.out.println("Car Make: " + make);
	System.out.println("Car Model: " + model);
	System.out.println("Manufacturing year: " + year);
	System.out.println("seatingCapacity: " + seatingCapacity);
}
}

class Truck extends Vehicle {
	double payloadCapacity;
	
	public Truck(String make, String model, int year, double payloadCapacity) {
		super(make, model, year);
		this.payloadCapacity = payloadCapacity;
	}
	
	public void DisplayDetails() {
		System.out.println("Truck Make: " + make);
		System.out.println("Truck Model: " + model);
		System.out.println("Manufacturing year: " + year);
		System.out.println("payloadCapacity: " + payloadCapacity + " tons.");
	}
}


























































































































































































































































































