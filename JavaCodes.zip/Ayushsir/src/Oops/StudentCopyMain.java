package Oops;

public class StudentCopyMain {
public static void main(String[] args) {
	StudentCopyConstruct s1 = new StudentCopyConstruct(1, "ajay");
	s1.Display();
	
	StudentCopyConstruct s2 = new StudentCopyConstruct(s1);
	s2.Display();
	
	StudentCopyConstruct s3 = new StudentCopyConstruct(s1);
	s3.Display();
}
}
