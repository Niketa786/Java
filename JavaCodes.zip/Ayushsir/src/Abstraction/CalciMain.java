package Abstraction;

public class CalciMain {
public static void main(String[] args) {
	Calculator cal = new Calculator();
	accessMethod(cal);
}

static void accessMethod (Calculator ref) {
	ref.add();
	ref.sub();
	ref.multiply();
	ref.divide();
}
}
