package Abstraction;

class Child1 extends Parent {
 void display1() {
	 System.out.println("Inside child1 display1.");
 }
 
 void display2() {
	 System.out.println("Inside child1 display2.");
 }
}
