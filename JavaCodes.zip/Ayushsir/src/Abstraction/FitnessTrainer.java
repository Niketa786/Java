package Abstraction;

abstract class FitnessTrainer {
  abstract void conductSession();
  abstract void giveAdvice();
}
