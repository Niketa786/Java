package Abstraction;

public class WorkMain {
public static void main(String[] args) {
	Employee e = new Employee();
	e.working();
	e.doProject();
}
}
