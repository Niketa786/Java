package Abstraction;

abstract class Calci2 extends Calci1 {
public abstract void multiply();
public abstract void divide();
}
