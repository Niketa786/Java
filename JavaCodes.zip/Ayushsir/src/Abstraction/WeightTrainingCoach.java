package Abstraction;

public class WeightTrainingCoach extends FitnessTrainer{
	public void conductSession() {
		System.out.println("conduct a weight training session...");
	}

	public void giveAdvice() {
		System.out.println("give advice on strength training and muscle gain...");
	}

}
