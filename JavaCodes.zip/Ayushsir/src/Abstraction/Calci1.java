package Abstraction;

abstract class Calci1 {
public abstract void add();
public void sub() {
	System.out.println("Substract method in Calci1.");
}
}
