package Abstraction;

public class SmartMain {
public static void main(String[] args) {
	SmartMain m = new SmartMain();
	
	SmartDevice smartLight = new SmartLight();
	SmartDevice smartSecurity = new SmartSecurity();
	m.operate(smartLight);
	m.operate(smartSecurity);
}

public static void operate(SmartDevice sd) {
	sd.turnOn();
	sd.turnOff();
}
}
