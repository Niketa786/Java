package Abstraction;

public class ShapeMain {
public static void main(String[] args) {
	Shape ref = new Suqare();
	ref.takeInput();
	ref.calculateArea();
}
}
