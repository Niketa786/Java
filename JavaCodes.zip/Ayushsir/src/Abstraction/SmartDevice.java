package Abstraction;

public interface SmartDevice {
void turnOn();
void turnOff();
}
