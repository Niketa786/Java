package Abstraction;

public class SmartLight implements SmartDevice {
public void turnOn() {
	System.out.println("Smart light turns on with adjustable brightness.");
	}

public void turnOff() {
	System.out.println("Smart light turns off.");
	}
}
