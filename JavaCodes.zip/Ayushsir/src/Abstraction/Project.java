package Abstraction;

public interface Project {
 void doProject();
}
