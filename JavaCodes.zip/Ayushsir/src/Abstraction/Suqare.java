package Abstraction;

import java.util.Scanner;

public class Suqare implements Shape {
	
	int side;
	
	@Override
	public void takeInput() {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the side of square: ");
		side = scan.nextInt();
	}
	
	@Override
	public void calculateArea() {
		int area = side * side;
		System.out.println("Area of square is: " + area);
	}
	
}
