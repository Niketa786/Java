package Abstraction;

abstract class Parent {
 abstract void display1();
 abstract void display2();
}
