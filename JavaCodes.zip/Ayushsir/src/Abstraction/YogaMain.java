package Abstraction;

public class YogaMain {
public static void main(String[] args) {
	YogaInstructor yoga = new YogaInstructor();
	WeightTrainingCoach weight = new WeightTrainingCoach();
	startWorkout(yoga);
	startWorkout(weight);
	
}

static void startWorkout(FitnessTrainer trainer) {
	trainer.conductSession();
	trainer.giveAdvice();
}
}
