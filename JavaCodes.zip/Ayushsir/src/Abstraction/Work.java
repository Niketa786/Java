package Abstraction;

public interface Work {
void working();
}
