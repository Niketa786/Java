package Abstraction;

public class SmartSecurity implements SmartDevice {
	public void turnOn() {
		System.out.println("system security armed.");
		}

	public void turnOff() {
		System.out.println("system security disarmed.");
		}
}
