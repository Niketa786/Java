package Abstraction;

class Calculator extends Calci2 {
 public void add() {
	 System.out.println("Addition functionality");
 }
 
 public void sub() {
	 System.out.println("subtract functionality");
 }
 
 public void multiply() {
	 System.out.println("multiplication functionality");
 }
 
 public void divide() {
	 System.out.println("division functionality");
 }
}
