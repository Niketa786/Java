package Abstraction;

public class Employee implements Work, Project {    //multiple inheritance
	
	@Override
 public void working() {
	 System.out.println("Employee is working...");
}
	
	@Override
	 public void doProject() {
		 System.out.println("Employee is doing project...");
	 }
}