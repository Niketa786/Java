package Abstraction;

abstract interface Shape {
	int a = 10;         //public static final int a = 10;
	
	 void takeInput();           //abstract public void takeInput();
	 void calculateArea();       //abstract public void calculateArea();
}
