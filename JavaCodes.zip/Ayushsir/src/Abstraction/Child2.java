package Abstraction;

public class Child2 extends Parent {
	 void display1() {
		 System.out.println("Inside child2 display1.");
	 }
	 
	 void display2() {
		 System.out.println("Inside child2 display2.");
	 }

}
