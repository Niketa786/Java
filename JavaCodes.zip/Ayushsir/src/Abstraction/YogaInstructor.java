package Abstraction;

 class YogaInstructor extends FitnessTrainer{
public void conductSession() {
	System.out.println("conduct a yoga session...");
}

public void giveAdvice() {
	System.out.println("give advice on flexibility and stress relief...");
}
}
