package Polymorphism;

public class Room {
	    public void book() {
	        System.out.println("Room booking is confirmed!");
	    }
	    public void checkIn() {
	        System.out.println("Guest checked into the room!");
	    }
	    public void checkOut() {
	        System.out.println("Guest checked out of the room!");
	    }
	}

