package Polymorphism;

public class RoomMain {
	 public static void main(String[] args) {
	        Room myRoom = new Room();
	        new RoomMain().processBooking(myRoom);
	    }

	    public void processBooking(Room room) {
	        room.book();
	        room.checkIn();
	        room.checkOut();
	    }
	}

