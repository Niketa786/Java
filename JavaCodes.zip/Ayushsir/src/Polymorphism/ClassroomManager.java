package Polymorphism;

public class ClassroomManager {
	    public void scheduleActivity(String activityType) {
	        System.out.println("Scheduled: " + activityType);
	    }

	    public void scheduleActivity(String activityType, int duration) {
	        System.out.println("Scheduled: " + activityType + " for " + duration + " minutes");
	    }

	    public void scheduleActivity(String activityType, int duration, int participants) {
	        System.out.println("Scheduled: " + activityType + " for " + duration + " minutes with " + participants + " participants");
	    }
	}

	
