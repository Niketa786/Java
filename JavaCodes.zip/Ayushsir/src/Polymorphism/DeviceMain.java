package Polymorphism;

public class DeviceMain {
public static void main(String[] args) {
	Device myDevice = new SmartPhone();
	myDevice.powerOn();
}
}
