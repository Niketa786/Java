package Polymorphism;

public class AdditionMain {
public static void main(String[] args) {
	Addition obj = new Addition();
	System.out.println(obj.add(4,5));
	System.out.println(obj.add(4.8,5));
	System.out.println(obj.add(4.5,5.8,5.5));
	System.out.println(obj.add(4.9,5.3));
	System.out.println(obj.add(3,5, 7.6));
}
}
