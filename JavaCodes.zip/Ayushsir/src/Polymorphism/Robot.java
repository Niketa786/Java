package Polymorphism;

public class Robot {
public void learn() {
	System.out.println("robots can learn almost anything.");
}

public void charge() {
	System.out.println("robots need charging to operate.");
}

public void tasks() {
	System.out.println("robots completes tasks efficiently.");
}
}
