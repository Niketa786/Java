package Polymorphism;

public class Device {
 public void powerOn() {
	 System.out.println("Device is powered on.");
 }
}

class SmartPhone extends Device {
	public void powerOn() {
		 System.out.println("SmartPhone is powered on with a touch screen interface.");
	 }
}