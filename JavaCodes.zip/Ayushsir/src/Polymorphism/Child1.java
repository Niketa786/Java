package Polymorphism;

public class Child1 extends Parent{
	void display2() {
		System.out.println("Inside child1 display2.");
	}
	
	void display3() {
		System.out.println("Inside child1 display3.");
	}
}