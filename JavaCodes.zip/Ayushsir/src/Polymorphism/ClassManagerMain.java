package Polymorphism;

public class ClassManagerMain {
	 public static void main(String[] args) {
	        ClassroomManager manager = new ClassroomManager();
	        manager.scheduleActivity("Lecture");
	        manager.scheduleActivity("Quiz", 45);
	        manager.scheduleActivity("Group Discussion", 30, 12);
	    } 
}
