package Polymorphism;

public class Child2 extends Parent{
	void display2() {
		System.out.println("Inside child2 display2.");
	}
	
	void display3() {
		System.out.println("Inside child2 display3.");
	}
}