package Polymorphism;

public class Person {
	    public static void work() {
	        System.out.println("Person is working.");
	    } 
	}

	class Employee extends Person {
	    public static void work() {
	        System.out.println("Employee is working.");
	    }
	}

	class Manager extends Employee {
	    public static void work() {
	        System.out.println("Manager is working.");
	    }
	}
