package Methods;

//public class Method1 {
//	public static void main(String[] args) { 
//		  String firstName = "Ajay";
//		  String lastName = "Singh";
//		  printName(firstName, lastName);
//		  
//		}
//	 static void printName(String firstName, String lastName) {
//		String FullName = firstName + lastName;
//		System.out.println(FullName);
//	 } 
//}



//public class Method1 {
//	public static void main(String[] args) { 
//		  long res = printLong(123456789012345L);
//		  System.out.println(res);
//		  
//		}
//	 static long printLong(long a) {
//		return a;
//	 } 
//}


//public class Method1 {
//	public static void main(String[] args) { 
//		  String message = "Hello World!";
//		  String res = printString(message);
//		  System.out.println(res);
//		  
//		}
//	 static String printString(String message) {
//		return message;
//	 } 
//}
//OR
//public class Method1 {
//	public static void main(String[] args) { 
//		  printString("Hello World!");
//		  
//		  
//		}
//	 static void printString(String message) {
//		System.out.println(message);;
//	 } 
//}

//public class Method1 {
//	public static void main(String[] args) { 
//		  printString("Hello", ", World!");
//		  
//		  
//		}
//	 static void printString(String str1, String str2 ) {
////		String fullName = str1 + str2;
////		System.out.println(fullName);
////		 OR
//		 System.out.println(str1+str2);
//	 } 
//}


public class Method1 {
	public static void main(String[] args) { 
//		 int res = getSum(5, 3); 
//		 System.out.println(res);
//		OR
		System.out.println(getSum());
		}
//	 static int getSum(int a, int b) {
	static int getSum() {
//           return a+b;
//		 OR
		 return 5+3;
	 } 
}
















