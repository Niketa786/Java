package Arrays;

import java.util.Scanner;
import java.util.Arrays;

public class CalculateArrAvg {
public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	int size = scan.nextInt();
	int[] arr = new int[size];
	
	for(int i = 0; i < size; i++) {
		arr[i]=scan.nextInt();
	}
	int sum = 0; 
	for(int i = 0; i < arr.length; i++) {
		sum += arr[i];
	}
	
	double avg = (double) sum / arr.length;
	System.out.println("Array: " + Arrays.toString(arr));
	
	System.out.println("Average: " + avg);
	scan.close();
}
}
