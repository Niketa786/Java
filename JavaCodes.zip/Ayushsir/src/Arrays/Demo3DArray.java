package Arrays;

import java.util.Scanner;

public class Demo3DArray {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the no. of blocks: ");
		int blocks = scan.nextInt();
		System.out.println("Enter the no. of rows: ");
		int rows = scan.nextInt();
		System.out.println("Enter the no. of cols: ");
		int col = scan.nextInt();
		
		int [][][] arr = new int[blocks][rows][col];
		

		for (int i = 0; i <= arr.length-1; i++) { //loop for blocks
			for (int j = 0; j <= arr[i].length-1; j++) { //loop for row
				for (int k = 0; k <= arr[i][j].length-1; k++) {         //loop for cols in each blocks and rows
		     System.out.println("enter the element to be stored in the blocks "+ i +" row :" +j+ " col: " + k);
			arr[i][j][k] = scan.nextInt();
		}
		}
		}
		
		System.out.println("The Array is : ");
		for (int i = 0; i <= arr.length-1; i++) { //loop for blocks
			for (int j = 0; j <= arr[i].length-1; j++) { //loop for row
				for (int k = 0; k <= arr[i][j].length-1; k++) {       //loop for cols in each blocks and rows
					
			     System.out.print(arr[i][j][k] +" ");
			     
		}
				System.out.println();
			}
			System.out.println();
		}
		System.out.println();
			scan.close();
		}
	}

	
