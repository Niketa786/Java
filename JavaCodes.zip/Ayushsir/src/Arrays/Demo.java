package Arrays;

import java.util.Scanner;

public class Demo {
public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	System.out.println("Enter the size of array: ");
	int[] arr = new int[scan.nextInt()];
	
	System.out.println("Enter the elements of array: ");
	for (int i = 0; i <= arr.length-1; i++) {
		arr[i] = scan.nextInt();
	}
	
	System.out.print("The Array is : ");
	System.out.print("[");
	for (int i = 0; i <= arr.length-1; i++) {
		if (i !=  arr.length-1) {
	 System.out.print(arr[i] + ", ");
	}
	else {
		 System.out.print(arr[i]);
		}
	}
	System.out.println("]");
	scan.close();
}
}
