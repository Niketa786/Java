package Arrays;

import java.util.Scanner;

public class ReverseArr {
public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	int size = scan.nextInt();
	int [] arr = new int[size];
	
	for (int i = 0; i <= arr.length-1; i++) {
		arr[i] = scan.nextInt();
	}
	
	int[] resArr = new int[size];
	int j = arr.length-1;
	
	for (int i = 0; i <= arr.length-1; i++) {
		resArr[j] = arr[i];
		j--;
	}
	
	System.out.print("Original array: [");
	for (int i = 0; i <= arr.length-1; i++) {
		if (i < arr.length-1) {
		System.out.print(arr[i] + ", "); 
	}
		else {
			System.out.print(arr[i]);
		}
	}
	System.out.println("]");
	
	System.out.print("Reversed array: [");
	for (int i = 0; i <= resArr.length-1; i++) {
		if (i < resArr.length-1) {
		System.out.print(resArr[i] + ", "); 
	}
		else {
			System.out.print(resArr[i]);
		}
	}
	System.out.println("]");
	
}
}
