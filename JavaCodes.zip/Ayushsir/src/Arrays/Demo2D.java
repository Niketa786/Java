package Arrays;

import java.util.Scanner;

public class Demo2D {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the no. of rows: ");
		int rows = scan.nextInt();
		System.out.println("Enter the no. of cols: ");
		int col = scan.nextInt();
		
		int[][] arr = new int[rows][col];
		

		for (int i = 0; i <= arr.length-1; i++) {
			for (int j = 0; j <= arr[i].length-1; j++) {
				
		     System.out.println("enter the element to be stored in the "+ i +" row :" + "col: " + j);
			arr[i][j] = scan.nextInt();
		}
		}
		
		System.out.println("The Array is : ");
		for (int i = 0; i <= arr.length-1; i++) {
			for (int j = 0; j <= arr[i].length-1; j++) {
				
			System.out.print(arr[i][j] + " ");
		}
			System.out.println();
		}
		scan.close();
	}
}
