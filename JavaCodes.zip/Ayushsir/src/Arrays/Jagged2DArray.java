package Arrays;

import java.util.Scanner;

public class Jagged2DArray {
public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	System.out.println("Enter no. of rows: ");
	
	int row = scan.nextInt();
	int[][] arr = new int[row][];
	
	for (int i = 0; i <= arr.length-1; i++) {
		System.out.println("Enter no. of cols of row: " + i);
		int col = scan.nextInt();
		arr[i] = new int[col];
	}
	
	
	
	for (int i = 0; i <= arr.length-1; i++) {
		for (int j = 0; j <= arr[i].length-1; j++) {
			System.out.println("enter the element to be stored in the "+ i +" row :" + "col: " + j);
		    arr[i][j] = scan.nextInt();
	}
	}
		System.out.println("The elements of Arrays: ");
		for (int i = 0; i <= arr.length-1; i++) {
			for (int j = 0; j <= arr[i].length-1; j++) {
				
			System.out.print(arr[i][j] + " ");
		}
			System.out.println();
	}
}
}
