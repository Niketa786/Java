package Arrays;

import java.util.Scanner;

public class ArraySum {
public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	int size = scan.nextInt();
	int[] arr = new int[size];
	
	for(int i = 0; i <= arr.length-1; i++) {
		arr[i]=scan.nextInt();
	}
	int sum = 0; 
	for(int i = 0; i < arr.length; i++) {
		sum += arr[i];
	}

		System.out.println(sum);
	}

}
