package Arrays;

import java.util.Scanner;

public class SumMinEle2DEachRow {
public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	System.out.println("Enter the no. of rows: ");
	int rows = scan.nextInt();
	System.out.println("Enter the no. of cols: ");
	int col = scan.nextInt();
	
	int[][] arr = new int[rows][col];
	

	for (int i = 0; i <= arr.length-1; i++) {
		for (int j = 0; j <= arr[i].length-1; j++) {
			
	     System.out.println("enter the element to be stored in the "+ i +" row :" + "col: " + j);
		arr[i][j] = scan.nextInt();
	}
	}
	
	System.out.println("The Array is : ");
	for (int i = 0; i <= arr.length-1; i++) {
		for (int j = 0; j <= arr[i].length-1; j++) {
			
		System.out.print(arr[i][j] + " ");
	}
		System.out.println();
	}
	
	int sum = 0;
	for(int i = 0; i <= arr.length-1; i++) {
		int min = arr[i][0];
    for(int j = 0; j <= arr[i].length-1; j++) {
    	if(arr[i][j] < min) {
    		min = arr[i][j];
    	}
    }
    System.out.println("Minimum of row " + (i+1) + ": " + min);
    sum = sum + min;
	}
	System.out.println("Sum of minimum elements: " + sum);
	scan.close();
}
}
