package Arrays;

import java.util.Scanner;

//public class Transpose2DArr {
//public static void main(String[] args) {
//	Scanner scan = new Scanner(System.in);
//	int row = scan.nextInt();
//	int col = scan.nextInt();
//	
//	int[][] arr = new int[row][col];
//	
//	for(int i = 0; i <= arr.length-1; i++) {
//		for (int j = 0; j <= arr.length-1; j++) {
//			arr[i][j] = scan.nextInt();
//		}
//	}
//	
//	int[][] Transpose = new int[col][row];
//	
//	for(int i = 0; i <= arr[i].length-1; i++) {
//		for (int j = 0; j <= arr[i].length-1; j++) {
//			Transpose[j][i] = arr[i][j]; 
//		}
//	}
//	
//	System.out.println("Original Matrix: ");
//	for(int i = 0; i <= arr.length-1; i++) {
//		for (int j = 0; j <= arr.length-1; j++) {
//		System.out.println(arr[i][j] + " ");
//		}
//		System.out.println();
//	}
//	
//	System.out.println("Transpose Matrix: ");
//	for(int i = 0; i <= Transpose.length-1; i++) {
//		for (int j = 0; j <= Transpose.length-1; j++) {
//		System.out.println(Transpose[i][j] + " ");
//		}
//		System.out.println();
//	}
//}
//}

public class Transpose2DArr {
public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    int row = scan.nextInt();
    int col = scan.nextInt();
    
    int[][] arr = new int[row][col];
    
    // 1. Correct Input Loop
    for(int i = 0; i < row; i++) {
        for (int j = 0; j < col; j++) {
            arr[i][j] = scan.nextInt();
        }
    }
    
    // 2. Correct Transpose Logic
    int[][] Transpose = new int[col][row];
    for(int i = 0; i < row; i++) {
        for (int j = 0; j < col; j++) {
            Transpose[j][i] = arr[i][j]; 
        }
    }
    
    // 3. Correct Printing (Original)
    System.out.println("Original Matrix: ");
    for(int i = 0; i < row; i++) {
        for (int j = 0; j < col; j++) {
            System.out.print(arr[i][j] + " "); // Use .print() here
        }
        System.out.println(); // New line after each row
    }
    
    // 4. Correct Printing (Transpose)
    System.out.println("Transpose Matrix: ");
    for(int i = 0; i < col; i++) { // Transpose has 'col' rows
        for (int j = 0; j < row; j++) { // Transpose has 'row' columns
            System.out.print(Transpose[i][j] + " ");
        }
        System.out.println();
    }
}
}