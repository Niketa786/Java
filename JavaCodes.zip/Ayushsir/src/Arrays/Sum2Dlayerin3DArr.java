package Arrays;

import java.util.Scanner;

public class Sum2Dlayerin3DArr {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		int depth = scan.nextInt();
		int rows = scan.nextInt();
		int col = scan.nextInt();
		
		int [][][] arr = new int[depth][rows][col];
		

		for (int i = 0; i <= arr.length-1; i++) { //loop for blocks
			for (int j = 0; j <= arr[i].length-1; j++) { //loop for row
				for (int k = 0; k <= arr[i][j].length-1; k++) {         //loop for col in each blocks and rows
			arr[i][j][k] = scan.nextInt();
		}
		}
		}
		
		System.out.println("3D Array: ");
		for (int i = 0; i <= arr.length-1; i++) { //loop for blocks
		System.out.println("Layer " + (i+1) + ": ");
			for (int j = 0; j <= arr[i].length-1; j++) { //loop for row
				for (int k = 0; k <= arr[i][j].length-1; k++) {       //loop for cols in each blocks and rows
					
			     System.out.print(arr[i][j][k] +" ");
			     
		}
				System.out.println();
       }
		}
		
		for (int i = 0; i <= arr.length-1; i++) { //loop for blocks
			int sum = 0;
			for (int j = 0; j <= arr[i].length-1; j++) { //loop for row
				for (int k = 0; k <= arr[i][j].length-1; k++) {       //loop for cols in each blocks and rows
					
			     sum = sum+arr[i][j][k];
				}  
		      }
				System.out.println("sum of layer " + (i+1) + ": " + sum);
           }
		scan.close();
		}
	}

