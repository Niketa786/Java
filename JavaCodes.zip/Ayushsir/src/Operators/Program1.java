package Operators;

public class Program1 {
	public static void main(String[] args) { 
	      var a = 10;
	System.out.println(a);
	 a--;
	 System.out.println(a);
	}
}



//public class program2 {
//public static void main(String[] args) { 
//    var a = 10;
//System.out.println(a);
//--a;
//System.out.println(a);
//}
//}


//public class Program3 {
//	public static void main(String[] args) { 
//	      var a = 10;
//	System.out.println(a);
//	 a--;
//	 System.out.println(a);
//	}
//}