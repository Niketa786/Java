package Operators;

public class Program {
	public static void main(String[] args) { 
      var a = 10;
System.out.println(a);
 ++a;
 System.out.println(a);
}
}
