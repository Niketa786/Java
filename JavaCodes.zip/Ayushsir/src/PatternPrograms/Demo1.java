package PatternPrograms;

//public class Demo1 {
//public static void main(String[] args) {
//	for (int i = 1; i <= 4; i++) {
//		System.out.println("*");
//	}
//}
//}

//public class Demo1 {
//public static void main(String[] args) {
//	for (int i = 1; i <= 4; i++) {
//		for (int j = 1; j <= 5; j++) {
//		System.out.print("*");
//	}
//		System.out.println();
//}
//}
//}

//public class Demo1 {
//public static void main(String[] args) {
//	for (int i = 1; i <= 4; i++) {
//		for (int j = 1; j <= 5; j++) {
//		System.out.print(i);
//	}
//		System.out.println();
//}
//}
//}

//public class Demo1 {
//public static void main(String[] args) {
//	for (int i = 1; i <= 4; i++) {                                   
//		for (int j = 1; j <= 5; j++) {
//		System.out.print(j);
//	}
//		System.out.println();
//}
//}
//}

//public class Demo1 {
//public static void main(String[] args) {
//	for (int i = 1; i <= 5; i++) {
//		for (int j = 1; j <= i; j++) {
//		System.out.print("*");
//	}
//		System.out.println();
//}
//}
//}

//public class Demo1 {
//public static void main(String[] args) {
//	for (int i = 1; i <= 6; i++) {
//		for (int j = 1; j <= 5; j++) {
//		if(i%2 != 0) {
//		System.out.print(" * ");
//		}
//		else {
//		System.out.print(" # ");
//	}
//		}
//		System.out.println();
//}
//}
//}

//public class Demo1 {
//public static void main(String[] args) {
//	for (int i = 1; i <= 5; i++) {
//		for (int j = 5; j >= i; j--) {
//		System.out.print("*");
//}
//		System.out.println();
//}
//}



//public class Demo1 {
//public static void main(String[] args) {
//	for (int i = 1; i <= 5; i++) {
//		for (int j = 1; j <= 5; j++) {
//		System.out.print("*");
//	}
//	
//	for (int j = 5; j >= i; j--) {
//			System.out.print("*");
//		}
//			System.out.println();
//	}
//		System.out.println();
//}
//}

//public class Demo1 {
//public static void main(String[] args) {
//	for (int i = 1; i <= 5; i++) {
//		for (int j = 1; j <= i; j++) {
//		System.out.print("*");
//	}
//		System.out.println();
//	}
//	for (int i = 2; i<= 5; i++) {
//	for (int j = 5; j >= i; j--) {
//			System.out.print("*");
//		}
//			System.out.println();
//	}
//}
//}

//public class Demo1 {
//public static void main(String[] args) {
//	for (int i = 1; i <= 5; i++) {
//		for (int j = 1; j <= i; j++) {
//		System.out.print(j);
//		}
//		System.out.println();
//
//}
//}
//}

//public class Demo1 {
//public static void main(String[] args) {
//	for (int i = 5; i >= 1; i--) {
//		for (int j = 1; j <= i; j++) {
//		System.out.print(i);
//		}
//		System.out.println();
//	}
//}
//}

//public class Demo1 {
//public static void main(String[] args) {
//	for (int i = 1; i <= 5; i++) {
//		for (int j = 1; j <= i; j++) {
//		System.out.print(i);
//		}
//		System.out.println();
//	}
//}
//}

//public class Demo1 {
//public static void main(String[] args) {
//	for (int i = 1; i <= 5; i++) {
//		for (int j = 4; j >= i; j--) {
//		System.out.print(" - ");
//		}
//		for (int k = 1; k <= i; k++) {
//			System.out.print(" * ");
//			}
//		System.out.println();
//	}
//}
//}

//public class Demo1 {
//public static void main(String[] args) {
//	for (int i = 1; i <= 5; i++) {
//		for (int j = 2; j <= i; j++) {
//			System.out.print(" - ");
//			}
//		for (int k = 5; k >= i; k--) {
//			System.out.print(" * ");
//			}
//		
//		System.out.println();
//	}
//}
//}

//public class Demo1 {
//public static void main(String[] args) {
//	for (int i = 1; i <= 5; i++) {
//		for (int k = 5; k >= i; k--) {
//			System.out.print("-");
//			}
//		for (int j = 1; j <= i; j++) {
//			System.out.print("* ");
//			}
//		System.out.println();
//	}
//}
//}

//public class Demo1 {
//public static void main(String[] args) {
//	for (int i = 1; i <= 5; i++) {
//		for (int k = 4; k >= i; k--) {
//			System.out.print("-");
//			}
//		for (int j = 1; j <= i; j++) {
//			System.out.print("* ");
//			}
//		System.out.println();
//	}
//	
//	for (int i = 2; i <= 5; i++) {
//		for (int k = 2; k <= i; k++) {
//			System.out.print("-");
//			}
//		for (int j = 5; j >= i; j--) {
//			System.out.print("* ");
//			}
//		System.out.println();
//	}
//}
//
//}

//public class Demo1 {
//public static void main(String[] args) {
//	for (int i = 1; i <= 5; i++) {
//		for (int j = 1; j <= 5; j++) {
//		if( i == 1 || i == 5 || j == 1 || j == 5) {
//		System.out.print(" * ");
//		}
//		else {
//		System.out.print(" - ");
//	}
//		}
//		System.out.println();
//}
//}
//}

//public class Demo1 {
//public static void main(String[] args) {
//	for (int i = 1; i <= 5; i++) {
//		for (int j = 1; j <= i; j++) {
//		if( i == 1 || i == 5 || j == 1 || j == i) {
//		System.out.print(" * ");
//		}
//		else {
//		System.out.print(" - ");
//	}
//		}
//		System.out.println();
//}
//}
//}


public class Demo1 {
public static void main(String[] args) {
	for (int i = 1; i <= 5; i++) {
		for (int k = 2; k <= i; k++) {
			System.out.print(" - ");
			}
		for (int j = 9; j >= (i*2)-1; j--) {
			System.out.print(" * ");
			}
		System.out.println();
	}
	
	for (int i = 2; i <= 5; i++) {
		for (int k = 4; k >= i; k--) {
			System.out.print(" - ");
			}
		for (int j = 1; j <= (i*2)-1; j++) {
			System.out.print(" * ");
			}
		System.out.println();
	}
}

}





















