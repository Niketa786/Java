package HAS_A_Relationship;

public class Book {
String title;
String author;

void displayBookDetails() {
	System.out.println("Book: " + title);
	System.out.println("Author: " + author);
}
}
