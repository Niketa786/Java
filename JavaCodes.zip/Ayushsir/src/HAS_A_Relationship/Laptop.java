package HAS_A_Relationship;

public class Laptop {

		OS os = new OS("Windows 11");
		
		Charger chg;
		
		void accessCharger(Charger ref) {
			chg = ref;
		}
		
	void showLapChargerDetails() {
			System.out.println("Laptop is using " + chg.brand + " charger.");
		}
	}

