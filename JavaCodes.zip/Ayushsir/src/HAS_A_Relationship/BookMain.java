package HAS_A_Relationship;

public class BookMain {
public static void main(String[] args) {
	Book myFavBook = new Book();
	 myFavBook.title = "1984";
	 myFavBook.author = "George Orwell";
	 
	 Library cityLibrary = new Library();
	 cityLibrary.addBook(myFavBook);
	 cityLibrary.showBook();
}
}
