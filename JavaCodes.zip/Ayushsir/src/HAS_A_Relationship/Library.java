package HAS_A_Relationship;

public class Library {
Book libraryBook;

void addBook(Book newBook) {
	libraryBook = newBook;
}

void showBook() {
	libraryBook.displayBookDetails();
}
}
