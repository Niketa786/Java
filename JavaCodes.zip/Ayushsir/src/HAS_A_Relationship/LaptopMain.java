package HAS_A_Relationship;

public class LaptopMain {
public static void main(String[] args) {
	Laptop lap = new Laptop();
	System.out.println("Laptop is using " + lap.os.name +" os.");
	lap.os.showOsDetails();
	
	Charger chg = new Charger("Dell");
	lap.accessCharger(chg);
	lap.showLapChargerDetails();
	chg.showChargerDatails();
}
}
