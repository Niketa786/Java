package HAS_A_Relationship;

public class Charger {

	String brand;
	
	public Charger(String brand) {
		this.brand = brand;
	}
	
	void showChargerDatails() {
		System.out.println("Charger brand is " + brand);
	}
	
	
	
}
