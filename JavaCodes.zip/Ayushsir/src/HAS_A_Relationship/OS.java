package HAS_A_Relationship;

public class OS {

	String name;
	
	public OS(String name) {
		this.name = name;
	}
	
	void showOsDetails() {
		System.out.println("OS name: " + name);
	}
}
