package HAS_A_Relationship;

public class ArtMain {
public static void main(String[] args) {
	Magazine myMagazine = new Magazine();
	myMagazine.featuredArticle.title = "Exploring Java";
	myMagazine.featuredArticle.content = "Java is a versatile and powerful Programming language...";
	
	myMagazine.displayFeaturedArticle();
}
}
