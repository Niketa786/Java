package HAS_A_Relationship;

public class Article {
String title;
String content;

void displayArticleDetails() {
	System.out.println("Article Title: " + title);
	System.out.println("Article Content: " + content);
}
}
