package HAS_A_Relationship;

public class Magazine {
Article featuredArticle = new Article();

void displayFeaturedArticle() {
	featuredArticle.displayArticleDetails();
}
}
