package AnatomyofMainMethod;

//public class Main {
//public static void main(String[] args) {
//	System.out.println(args[0]);
//	System.out.println(args[1]);
//}
//}


public class Main {
public static void main(String[] args) {
	
	for(int i = 0; i <= args.length-1; i++ ) {
	System.out.println(args[i]);
}
}
}