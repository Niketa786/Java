package ThreadPack;
import java.util.Scanner;

public class Printing extends Thread {

	@Override
	public void run() {
		System.out.println("printing activity started");
		int n = 5;
		for (int i = 1; i <= n; i++) {
			System.out.println("KodNest");
			
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println("printing activity completed");
	}
}

