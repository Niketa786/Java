package ThreadPack;

public class Main3 {
public static void main(String[] args) {
	PrintingNum pn = new PrintingNum();
	Addition ad = new Addition();
	PrintingChar pc = new PrintingChar();
//	pn.start();
//	ad.start();
//	pc.start();
	
	Thread t1 = new Thread(pn);
	Thread t2 = new Thread(ad);
	Thread t3 = new Thread(pc);
	t1.start();
	t2.start();
	t3.start();
	
	try {
		t1.join();
		t2.join();
		t3.join();
	} catch (InterruptedException e) {
		e.printStackTrace();
	}
}
}
