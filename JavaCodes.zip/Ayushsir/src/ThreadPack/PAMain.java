package ThreadPack;
import java.util.Scanner;

public class PAMain {
public static void main(String[] args) {
	Printing p = new Printing();
	Addition a = new Addition();
	p.start();   //start method internally call run()
	a.start();
}
}
