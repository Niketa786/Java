package ThreadPack;

//public class PrintingChar extends Thread {
//	@Override
//	public void run() {
//		System.out.println("Printing Char activity started.");
//		for (char ch = 'A'; ch <= 'I'; ch++) {
//			System.out.println(ch);
//			try {
//				Thread.sleep(ch);
//			} catch (InterruptedException e) {
//				e.printStackTrace();
//			}
//		}
//		System.out.println("printing char activity completed");
//	}
//
//} 


public class PrintingChar implements Runnable {
	@Override
	public void run() {
		System.out.println("Printing Char activity started.");
		for (char ch = 'A'; ch <= 'I'; ch++) {
			System.out.println(ch);
			try {
				Thread.sleep(ch);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println("printing char activity completed");
	}

} 