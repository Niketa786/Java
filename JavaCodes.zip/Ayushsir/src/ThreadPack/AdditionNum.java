package ThreadPack;

import java.util.Scanner;

//public class AdditionNum extends Thread {
//	@Override
//	public void run() {
//		System.out.println("AdditionNum activity started.");
//		Scanner scan = new Scanner(System.in);
//		System.out.println("Enter first number: ");
//		int a = scan.nextInt();
//		System.out.println("Enter second number: ");
//		int b = scan.nextInt();
//		int res = a + b;
//		System.out.println("Addition result is " + res);
//		System.out.println("Addition activity completed.");
//
//}
//}


public class AdditionNum implements Runnable {
	@Override
	public void run() {
		System.out.println("AdditionNum activity started.");
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter first number: ");
		int a = scan.nextInt();
		System.out.println("Enter second number: ");
		int b = scan.nextInt();
		int res = a + b;
		System.out.println("Addition result is " + res);
		System.out.println("Addition activity completed.");

}
}