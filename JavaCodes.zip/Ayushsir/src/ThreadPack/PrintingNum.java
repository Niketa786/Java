package ThreadPack;

//public class PrintingNum extends Thread {
//	@Override
//	public void run() {
//		System.out.println("Printing num activity started.");
//		for (int i = 0; i <= 5; i++) {
//			System.out.println(i);
//			try {
//				Thread.sleep(3000);
//			} catch (InterruptedException e) {
//				e.printStackTrace();
//			}
//		}
//		System.out.println("printing num activity completed");
//	}
//
//}
 

public class PrintingNum implements Runnable {
	@Override
	public void run() {
		System.out.println("Printing num activity started.");
		for (int i = 0; i <= 5; i++) {
			System.out.println(i);
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println("printing num activity completed");
	}

}