package CollectionFramework;
import java.util.TreeSet;
import java.util.ArrayDeque;

public class ExampleTreeSet {
public static void main(String[] args) {
	ArrayDeque ad = new ArrayDeque();
	ad.add(100);
	ad.add(25);
	ad.add(75);
	ad.add(50);
	ad.add(150);
	ad.add(125);
	ad.add(175);
	
	System.out.println(ad);
	
	TreeSet ts = new TreeSet();
	ts.addAll(ad);
	System.out.println(ts);

	
	System.out.println(ts.headSet(75));         //[25, 50]
	System.out.println(ts.headSet(75, true));   //[25, 50, 75]
	
	System.out.println(ts.tailSet(100));        //[100, 125, 150, 175]
	System.out.println(ts.tailSet(100, false)); //[125, 150, 175]
	
	System.out.println(ts.higher(100));  //125
	System.out.println(ts.higher(80));   //100
	
	System.out.println(ts.lower(100));  //75
	System.out.println(ts.lower(80));   //75
	
	System.out.println(ts.ceiling(75));  //100
	System.out.println(ts.ceiling(75));  //100
	
	System.out.println(ts.floor(100));   //100
	System.out.println(ts.floor(80));    //75
}
}
