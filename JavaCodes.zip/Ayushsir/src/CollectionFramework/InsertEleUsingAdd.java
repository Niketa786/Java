package CollectionFramework;

import java.util.ArrayList;
import java.util.Scanner;

public class InsertEleUsingAdd {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int n = scan.nextInt();
		
		ArrayList<String> list = new ArrayList<>();
		
		for(int i = 0; i < n; i++) {
			list.add(scan.next());
		}
		int index = scan.nextInt();
		String newString = scan.next();
		
		list.add(index, newString);
		System.out.println("Updated ArrayList: ");
		for(String s: list) {
			System.out.println(" " + s);
		}
		scan.close();
	}
}
