package CollectionFramework;

import java.util.ArrayList;
import java.util.Collections;

public class Stu1Main {
public static void main(String[] args) {
	Student1 s1 = new Student1(11, "Amit", 80.5);
	Student1 s2 = new Student1(13, "Rohit", 70.5);
	Student1 s3 = new Student1(12, "Mohit", 60.5);
	
	ArrayList al = new ArrayList();
	al.add(s1);
	al.add(s2);
	al.add(s3);
	System.out.println(al);
	
	Collections.sort(al);
	System.out.println(al);
}
}
