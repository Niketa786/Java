package CollectionFramework;
import java.util.ArrayList;
import java.util.Scanner;

public class Demo {
public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	int n = scan.nextInt();
	
	ArrayList<Integer> list = new ArrayList<>();
	
	for(int i = 0; i < n; i++) {
		int num = scan.nextInt();
		list.add(num);
	}
	System.out.println("size: " + list.size());
	
	System.out.print("Elements: ");
	for(int num: list) {
		System.out.print(" " + num);
	}
	scan.close();
}
}
