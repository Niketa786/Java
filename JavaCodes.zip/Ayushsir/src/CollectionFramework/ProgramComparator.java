package CollectionFramework;

public class ProgramComparator {
int roll;
String name;
double marks;

public ProgramComparator(int roll, String name, double marks) {
	this.roll = roll;
	this.name = name;
	this.marks = marks;
}
public String toString() {
	return roll + " " + name + " " + marks;
}
}
