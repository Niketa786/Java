package CollectionFramework;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Scanner;


public class ImplementArrDeque {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	int n = sc.nextInt();
	ArrayDeque ad = new ArrayDeque();
	
	for(int i = 1; i <= n; i++) {
		ad.add(sc.nextInt());
	}
	ad.addFirst(sc.nextInt());
	ad.addLast(sc.nextInt());
	ad.removeFirst();
	ad.removeLast();
	
	System.out.println("Updated queue of customer ID's");
	for (Object x: ad) {
		System.out.println(x + " ");
	}
	sc.close();
}
}
