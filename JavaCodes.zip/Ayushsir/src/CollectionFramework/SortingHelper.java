package CollectionFramework;
import java.util.Comparator;

public class SortingHelper implements Comparator<ProgramComparator> {
@Override
public int compare(ProgramComparator obj1, ProgramComparator obj2) {
	return obj1.roll - obj2.roll;
}
}
