package CollectionFramework;
//
//import java.util.ArrayList;
//import java.util.Collections;
//import java.util.Scanner;
//
//public class IntDescOrderComparator {
//public static void main(String[] args) {
//	Scanner scan = new Scanner(System.in);
//	int n = scan.nextInt();
//	ArrayList<Integer> al = new ArrayList<>();
//	for (int i = 0; i < n; i++) {
//		al.add(scan.nextInt());
//	}
//	
//	Collections.sort(al, newComparator<Integer>(){
//			public int compare(Integer obj1, Integer obj2) {
//				int a = Integer.valueOf(obj1);
//				int a = Integer.valueOf(obj2);
//				return a - b;
//			}
//	});
//	System.out.println("Integer sorted in descending Order: ");
//	for (Object x : al) {
//		System.out.print(x + " ");
//	}
//	scan.close();
//}
//}

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator; // Added this import
import java.util.Scanner;

public class IntDescOrderComparator {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter number of elements:");
        int n = scan.nextInt();
        
        ArrayList<Integer> al = new ArrayList<>();
        
        System.out.println("Enter " + n + " integers:");
        for (int i = 0; i < n; i++) {
            al.add(scan.nextInt());
        }

        // Fixed the anonymous inner class syntax
        Collections.sort(al, new Comparator<Integer>() {
            @Override
            public int compare(Integer obj1, Integer obj2) {
                // For descending order: second element - first element
                return obj2 - obj1; 
            }
        });

        System.out.println("Integers sorted in descending order: ");
        for (Integer x : al) {
            System.out.print(x + " ");
        }
        
        scan.close();
    }
}





