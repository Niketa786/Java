package CollectionFramework;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.Map; // Needed if you use Map.Entry

public class StudentHpMain {
public static void main(String[] args) {
	StudentHp s1 = new StudentHp(11, "Amit", 87.5);
	StudentHp s2 = new StudentHp(12, "Sumit", 68.5);
	StudentHp s3 = new StudentHp(13, "Rohit", 78.5);
	
	HashMap hm = new HashMap();
//	hm.put(1, 100);
//	hm.put(2, 300);
//	hm.put(3, 400);
//	hm.put(4, 200);
	
	hm.put(1, s1);
	hm.put(2, s2);
	hm.put(3, s3);
	
	System.out.println(hm);
	
	//Traverse the Keys
	System.out.println("Keys: ");
	Set res1 = hm.keySet();
	Iterator iter1 = res1.iterator();
	while(iter1.hasNext()) {
		System.out.println(iter1.next());
	}
	
	//Traverse the values
	System.out.println("Values: ");
	Collection res2 = hm.values();
	Iterator iter2 = res2.iterator();
	while(iter2.hasNext()) {
		System.out.println(iter2.next());
	}
	
	//Traverse the key-Values
	System.out.println("Key-Values: ");
	Set res3 = hm.entrySet();
	Iterator iter3 = res3.iterator();
	while(iter3.hasNext()) {
		System.out.println(iter3.next());
	}
}
}
