package CollectionFramework;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

public class CollectionSortMethod {
public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	  
    ArrayList<Integer> marks = new ArrayList<>();
    
    for (int i = 1; i <=  5; i++) {
        marks.add(scan.nextInt());
    }

    // Fixed the anonymous inner class syntax
    Collections.sort(marks, Comparator.reverseOrder()); 
    System.out.println("sorted marks(Descending): " + marks);
    scan.close();
}
}

