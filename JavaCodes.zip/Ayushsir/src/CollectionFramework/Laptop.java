package CollectionFramework;

//public class Laptop implements Comparable<Laptop>{
//int id;
//String processor;
//double price;
//
//Laptop(int id, String processor, double price) {
//	this.id = id;
//	this.processor = processor;
//	this.price = price;
//}
//
//@Override
//public int compareTo(Laptop O) {
//	return id - O.id;
//}
//
//@Override
//public String toString() {
//	return "Laptop [ id = " + id + ", processor = " + processor + ", price = " + price + "]";
//}
//}


public class Laptop{
int id;
String processor;
double price;

Laptop(int id, String processor, double price) {
	this.id = id;
	this.processor = processor;
	this.price = price;
}

@Override
public String toString() {
	return "Laptop [ id = " + id + ", processor = " + processor + ", price = " + price + "]";
}
}