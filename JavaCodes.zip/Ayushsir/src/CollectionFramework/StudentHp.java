package CollectionFramework;

public class StudentHp {
 int roll;
 String name;
 double marks;
 
 public StudentHp(int roll, String name, double marks) {
	 this.roll = roll;
	 this.name = name;
	 this.marks = marks;
 }
 
 @Override
public String toString() {
	return "StudentHp [roll=" + roll + ", name=" + name + ", marks=" + marks + "]";
}
}
