package CollectionFramework;

import java.util.ArrayList;
import java.util.Collections;

public class MainComparator {
public static void main(String[] args) {
	ProgramComparator p1 = new ProgramComparator(11, "Amit", 80.5);
	ProgramComparator p2 = new ProgramComparator(13, "Rohit", 70.5);
	ProgramComparator p3 = new ProgramComparator(12, "Mohit", 60.5);
	
	ArrayList al = new ArrayList();
	al.add(p1);
	al.add(p2);
	al.add(p3);
	System.out.println(al);
	
	SortingHelper sh = new SortingHelper();
	Collections.sort(al, sh);
	System.out.println(al);
}
}
