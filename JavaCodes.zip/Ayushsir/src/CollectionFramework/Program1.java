package CollectionFramework;
import java.util.ArrayList;

public class Program1 {
public static void main(String[] args) {
	ArrayList al = new ArrayList();
	al.add(10);
	al.add(40);
	al.add(20);
	al.add(50);
	al.add(30);
	System.out.println(al);
	
	al.add("Java");
	al.add("SQL");
	al.add(100.5);
	al.add(true);
	al.add('k');
	System.out.println(al);
	System.out.println(al.size());  //10
	System.out.println(al.contains(50));   //true
	System.out.println(al.contains(100));   //false
	System.out.println(al.get(3));     //50
	System.out.println(al.getFirst());  //10
	System.out.println(al.getLast());    //k
	System.out.println(al.indexOf(20));    //2
	System.out.println(al.isEmpty());       //false
	al.remove(1);
	System.out.println(al);
	al.add(20);
	System.out.println(al);
	al.lastIndexOf(20);
	System.out.println(al);
	al.removeFirst();
	System.out.println(al);
	al.removeLast();
	System.out.println(al);
	al.set(2, "HTML");
	System.out.println(al);
	al.add(2, 99);
	System.out.println(al);
	
	ArrayList al1 = new ArrayList();
	al1.add(100);
	al1.add(200);
	al1.add(300);
	System.out.println(al1);
	al.addAll(al1);
	System.out.println(al);
	
	System.out.println("traversing using for loop: ");
	for(int i = 0; i <= al.size()-1; i++) {
		System.out.print(al.get(i) + " ");
	}
	System.out.println();
}
}
