package CollectionFramework;

import java.util.Scanner;
import java.util.Queue;
import java.util.LinkedList;

public class QueInterface {
public static void main(String[] args) {
	Queue<Integer> queue = new LinkedList<Integer>();
	queue.add(10); //10
	queue.add(20); //10 20
	queue.add(30); //10 20 30
	queue.add(40); //10 20 30 40
	queue.add(50); //10 20 30 40 50
	
//	System.out.println(queue.remove());  //10
//	System.out.println(queue.remove());  //20
//	System.out.println(queue.remove());  //30
//	System.out.println(queue.remove());  //40
//	System.out.println(queue.remove());  //50
	
	System.out.println(queue.poll());  //10
	System.out.println(queue.poll());  //20
	System.out.println(queue.poll());  //30
	System.out.println(queue.poll());  //40
	System.out.println(queue.poll());  //50
	
//	System.out.println(queue.peek());  //10
//	System.out.println(queue.peek());  //10
//	System.out.println(queue.peek());  //10
//	System.out.println(queue.peek());  //10
//	System.out.println(queue.peek());  //10
}
}
