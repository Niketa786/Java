package CollectionFramework;
import java.util.ArrayList;
import java.util.Scanner;

public class Demo1 {
public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	int n = scan.nextInt();
	
	ArrayList<Integer> list = new ArrayList<>();
	
	for(int i = 0; i < n; i++) {
		int num = scan.nextInt();
		list.add(num);
	}
	
	int index = scan.nextInt();
	
	System.out.print("Elements at index " + index + ": " + list.get(index));
	scan.close();
}
}
