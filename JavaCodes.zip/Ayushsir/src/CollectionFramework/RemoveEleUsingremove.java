package CollectionFramework;

import java.util.ArrayList;
import java.util.Scanner;

public class RemoveEleUsingremove {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int n = scan.nextInt();
		
		ArrayList<Integer> list = new ArrayList<>();
		
		for(int i = 0; i < n; i++) {
			list.add(scan.nextInt());
		}
		
		int index = scan.nextInt();
		list.remove(index);
		
		System.out.println("Updated ArrayList: ");
		for(int num: list) {
			System.out.println(num + " ");
		}
		scan.close();
	}
}
