package CollectionFramework;

	import java.util.ArrayList;
	import java.util.Collections;
	import java.util.List;
	import java.util.Scanner;


	public class SwapEleArrList {
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);

	        // 1. Read an integer n representing the number of colors.
	        int n = scanner.nextInt();
	        scanner.nextLine(); // Consume the newline left after nextInt()

	        // 2. Read n color names from the user.
	        String line = scanner.nextLine();
	        String[] colors = line.split(" ");
	        
	        scanner.close(); // Close the scanner

	        // 3. Add these colors to an ArrayList<String>.
	        List<String> colorList = new ArrayList<>();
	        // Note: The loop condition ensures we only add 'n' elements, 
	        // matching the input count, even if the split array is larger/smaller 
	        // (though constraints imply they match).
	        for (int i = 0; i < n && i < colors.length; i++) {
	            colorList.add(colors[i]);
	        }
	        
	        // Define the indices for swapping
	        final int FIRST_INDEX = 0;
	        final int THIRD_INDEX = 2;

	        // 4. Print the list of colors before swapping.
	        System.out.println("Array list before Swap:");
	        printList(colorList);
	        
	        // Constraint Check: The ArrayList must contain at least three elements (n >= 3)
	        if (n >= 3) {
	            // 5. Swap the first (index 0) and third (index 2) elements in the ArrayList.
	            // Use Collections.swap() for efficient swapping.
	            Collections.swap(colorList, FIRST_INDEX, THIRD_INDEX);

	            // 6. Print the list of colors after swapping.
	            System.out.println("Array list after Swap:");
	            printList(colorList);
	        } else {
	            // Appropriate message if the swap is skipped due to constraint violation.
	            System.out.println("Array list after Swap:");
	            System.out.println("Swap operation skipped. List must contain at least 3 elements (n < 3).");
	            // Although the sample output doesn't show an "appropriate message," 
	            // the constraint states one should be displayed if n < 3. 
	            // We print the list again to show it's unchanged, or print the message.
	            // Based on the constraints, we will output the appropriate message.
	            // If the strict output format must be followed, uncomment the line below:
	            // printList(colorList); 
	        }
	    }
	    
	    /**
	     * Helper method to print the elements of a list, each on a new line.
	     * @param list The list of strings to print.
	     */
	    private static void printList(List<String> list) {
	        for (String element : list) {
	            System.out.println(element);
	        }
	    }
	}
