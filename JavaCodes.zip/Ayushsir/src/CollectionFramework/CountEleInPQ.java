package CollectionFramework;

import java.util.PriorityQueue;
import java.util.Scanner;

public class CountEleInPQ {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int n = scan.nextInt();
		
		PriorityQueue pq = new PriorityQueue();
		
		for(int i = 0; i < n; i++) {
			pq.add(scan.nextInt());
		}
		
		pq.add(scan.nextInt());
		System.out.println("Number of elements in the priority queue: " + pq.size());
		scan.close();
}
}