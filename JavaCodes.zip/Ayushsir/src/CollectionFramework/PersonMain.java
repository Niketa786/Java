package CollectionFramework;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class PersonMain {
public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	int n = scan.nextInt();
	
	ArrayList al = new ArrayList();
	for (int i = 0; i < n; i++) {
		String name = scan.next();
		int age = scan.nextInt();
		Person p = new Person(name, age);
		al.add(p);
	}
	
	Collections.sort(al);
	System.out.println("People sorted by age: ");
	for(Object pr: al) {
		System.out.println(pr);
	}
	scan.close();
}
}
