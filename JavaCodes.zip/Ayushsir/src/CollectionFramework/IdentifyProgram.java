package CollectionFramework;
import java.util.*;


public class IdentifyProgram {
public static void main(String[] args) {
	HashMap hm = new HashMap();
	String s1 = new String("key");
	String s2 = new String("key");
	
	hm.put(s1, "Value1");
	hm.put(s2, "Value2");
	System.out.println(hm);
	
	IdentityHashMap<String, String> ihm = new IdentityHashMap<String, String>();
	
	ihm.put(s1, "Val1");
	ihm.put(s2, "Val2");
	
	System.out.println(ihm);
}
}