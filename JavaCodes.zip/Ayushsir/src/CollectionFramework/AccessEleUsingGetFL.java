package CollectionFramework;

import java.util.LinkedList;
import java.util.Scanner;

public class AccessEleUsingGetFL {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int n = Integer.parseInt(scan.nextLine());
		
		LinkedList<String> attendees = new LinkedList<>();
		
		for(int i = 0; i < n; i++) {
			String name = scan.nextLine();
			attendees.addLast(name);
		}
		
		//Retrieve first and last attendees
		String firstAttendee = attendees.getFirst();
		String LastAttendee = attendees.getLast();
		
		System.out.println("First Attendees: " + firstAttendee);
		System.out.println("Last Attendees: " + LastAttendee);
		System.out.println("Number of Attendees: " + attendees.size());
		System.out.println("Attendees: ");
		
		
		for(String Attendee: attendees) {
			System.out.println(Attendee);
		}
		scan.close();
	}
}
