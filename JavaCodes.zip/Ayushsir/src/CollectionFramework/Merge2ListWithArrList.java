package CollectionFramework;

	import java.util.ArrayList;
	import java.util.List;
	import java.util.Scanner;

	public class Merge2ListWithArrList {
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);

	        // 1. Read an integer n1 representing the number of colors in the first list.
	        int n1 = scanner.nextInt();
	        scanner.nextLine(); // Consume the newline

	        // Initialize the first list
	        List<String> list1 = new ArrayList<>();

	        // Read the line containing n1 space-separated color names
	        String line1 = scanner.nextLine();
	        String[] colors1 = line1.split(" ");

	        // 2. Read n1 color names and add them to the first ArrayList<String>.
	        // Use a loop or check if n1 is consistent with the split array length
	        for (int i = 0; i < n1 && i < colors1.length; i++) {
	            list1.add(colors1[i]);
	        }


	        // 3. Read an integer n2 representing the number of colors in the second list.
	        int n2 = scanner.nextInt();
	        scanner.nextLine(); // Consume the newline

	        // Initialize the second list
	        List<String> list2 = new ArrayList<>();

	        // Read the line containing n2 space-separated color names
	        String line2 = scanner.nextLine();
	        String[] colors2 = line2.split(" ");
	        
	        // 4. Read n2 color names and add them to the second ArrayList<String>.
	        for (int i = 0; i < n2 && i < colors2.length; i++) {
	            list2.add(colors2[i]);
	        }

	        scanner.close(); // Close the scanner

	        // 5. Merge both lists into a new ArrayList<String>.
	        // Initialize the merged list by copying the first list
	        List<String> mergedList = new ArrayList<>(list1);
	        
	        // Add all elements from the second list to the end of the merged list
	        mergedList.addAll(list2);

	        // 6. Print all three lists: the first list, the second list, and the merged list.
	        
	        // Helper method to format list output
	        System.out.print("List of first array:");
	        printList(list1);

	        System.out.print("List of second array:");
	        printList(list2);

	        System.out.print("New array:");
	        printList(mergedList);
	    }
	    
	    /**
	     * Helper method to print the elements of a list separated by spaces.
	     * @param list The list to print.
	     */
	    private static void printList(List<String> list) {
	        for (String element : list) {
	            System.out.print(" " + element);
	        }
	        System.out.println();
	    }
	}
