package CollectionFramework;
import java.util.PriorityQueue;
import java.util.Scanner;

public class ImplementPQ {
public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	int n = scan.nextInt();
	
	PriorityQueue<Integer> queue = new PriorityQueue<>();
	
	for(int i = 0; i < n; i++) {
		int priority = scan.nextInt();
		queue.add(priority);
	}
	
	if(scan.hasNextInt()) {
		int newPriority = scan.nextInt();
		queue.add(newPriority);
	}
	
	if(!queue.isEmpty()) {
		queue.poll();
	}
	System.out.println("Updated queue of task priorities: "); 
	
	PriorityQueue<Integer> tempQueue = new PriorityQueue<>(queue);
	while(!tempQueue.isEmpty()) {
		System.out.print(tempQueue.poll() + " ");
	}
	System.out.println();
	scan.close();
}
}
