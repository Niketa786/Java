package CollectionFramework;

import java.util.LinkedHashMap;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class StuLinkedHashMap {
public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	LinkedHashMap<Integer, String> lhm = new LinkedHashMap<Integer, String>();
	int n = scan.nextInt();
	
	for (int i = 1; i <= n; i++) {
		int roll = scan.nextInt();
		String name = scan.next();
		lhm.put(roll, name);
		System.out.println("Added: Roll " + roll + " -> " + name);
	}
	
	int retrieveRoll = scan.nextInt();
	String retrieveName = lhm.get(retrieveRoll);
	
	if (retrieveName != null) {
		System.out.println("Student name: " + retrieveName);
	} else {
		System.out.println("Student not found.");
	}
	
	int removeRoll = scan.nextInt();
	String removeName = lhm.remove(removeRoll);
	if (removeName != null) {
		System.out.println("Student removed: " + removeName);
	} else {
		System.out.println("Student not found.");
	}
	
	for (Map.Entry<Integer, String> res: lhm.entrySet()) {
		System.out.println("Roll: " + res.getKey() + ", Name: " + res.getValue());
	}
	scan.close();
}
}

