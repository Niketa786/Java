package CollectionFramework;

import java.util.HashSet;
import java.util.Objects;

public class StudentMain {
public static void main(String[] args) {
	Student s1 = new Student(11, "Arjun");
	Student s2 = new Student(12, "Ravi");
	Student s3 = new Student(11, "Arjun");
	
	s1.display();
	s2.display();
	s3.display();
	
	System.out.println(s1.equals(s2));
	System.out.println(s1.equals(s3));
	
	HashSet hs = new HashSet();
	hs.add(s1);
	hs.add(s2);
	hs.add(s3);
	System.out.println(hs);
	
	@Override
	public int hashCode() {
		return Objects.hash(roll, name);
	}
	
	@Override
	public String toString() {
		return roll + " " + name;
	}
}
}
