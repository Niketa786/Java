package CollectionFramework;

import java.util.Objects;

public class Car {
private String model;
private int year;

public Car(String model, int year) {
	this.model = model;
	this.year = year;
}

@Override
public boolean equals(Object obj) {
	Car car = (Car)obj;
	if (year == car.year && model.equals(car.model)) {
		return true;
	} else {
		return false;
	}
}
@Override
public int hashCode() {
	return Objects.hash(model,year);
}

@Override
public String toString() {
	return "Car {Model: '" + model + "', Year: " + year + "}";

}
}
