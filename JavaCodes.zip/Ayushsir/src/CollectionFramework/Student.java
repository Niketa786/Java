package CollectionFramework;

public class Student {
int roll;
String name;

Student(int roll, String name) {
	this.roll = roll;
	this.name = name;
} 

void display() {
	System.out.println(roll + " " + name);
}

@Override
public boolean equals(Object obj) {
	Student s = (Student) obj;
	if (this.roll == s.roll && this.name.equals(s.name)) {
		return true;
	} else {
		return false;
	}
}
}
