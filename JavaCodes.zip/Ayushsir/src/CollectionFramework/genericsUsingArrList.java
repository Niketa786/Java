package CollectionFramework;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class genericsUsingArrList {
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // 1. Read an integer n representing the number of elements.
        int n = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character left after nextInt()

        // 2. Read n elements of a specified type (Integer, String, or Double).
        String dataType = scanner.nextLine().trim();

        // The third line contains n space-separated elements, read as a single string.
        String elementsLine = scanner.nextLine();
        String[] elements = elementsLine.split(" ");
        
        // Check if the number of elements read matches n (for robustness, though 
        // the constraints imply it will match).
        if (elements.length != n) {
            // This is a simple error handling for mismatched input count
            // System.err.println("Error: Expected " + n + " elements but found " + elements.length);
            // return;
        }

        // Initialize a generic List reference.
        List<?> list = null;

        // Use a switch to handle different data types and initialize the appropriate ArrayList.
        switch (dataType) {
            case "Integer":
                List<Integer> intList = new ArrayList<>();
                for (String element : elements) {
                    try {
                        intList.add(Integer.parseInt(element));
                    } catch (NumberFormatException e) {
                        // Skip or handle elements that don't match the type
                    }
                }
                list = intList; // Assign the populated list to the generic reference
                break;

            case "String":
                List<String> stringList = new ArrayList<>();
                // 3. Add these elements to a generic ArrayList.
                for (String element : elements) {
                    stringList.add(element);
                }
                list = stringList; // Assign the populated list to the generic reference
                break;

            case "Double":
                List<Double> doubleList = new ArrayList<>();
                for (String element : elements) {
                    try {
                        doubleList.add(Double.parseDouble(element));
                    } catch (NumberFormatException e) {
                        // Skip or handle elements that don't match the type
                    }
                }
                list = doubleList; // Assign the populated list to the generic reference
                break;
                
            default:
                // System.err.println("Error: Invalid data type specified: " + dataType);
                scanner.close();
                return;
        }
        
        scanner.close();

        // 4. Print the size of the ArrayList.
        System.out.println("Size: " + list.size());

        // 5. Print all elements in the order they were added.
        System.out.print("Elements:");
        for (int i = 0; i < list.size(); i++) {
            System.out.print(" " + list.get(i));
        }
        System.out.println(); // For a final newline
    }
}