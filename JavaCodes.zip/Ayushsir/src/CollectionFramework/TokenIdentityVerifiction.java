package CollectionFramework;
import java.util.*;

public class TokenIdentityVerifiction {
public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	WeakHashMap<Integer, String> sessionTokens = new WeakHashMap<>();
	int n = scan.nextInt();
	scan.nextInt();scan.nextLine();

	for(int i = 0; i < n; i++) {
		int tokenId = scan.nextInt();
		String TokenValue =  scan.next();
		sessionTokens.put(tokenId, TokenValue);
		System.out.println("Added token: " + tokenId + " -> " + TokenValue);
	}
	
	System.out.println("enter a token ID to check: ");
	int checkTokenId = scan.nextInt();
	boolean exists = sessionTokens.containsKey(checkTokenId);
	System.out.println("Token" + checkTokenId + "exists: " + exists);
	
	System.out.println("All active session Tokens: ");
	for (Map.Entry<Integer, String> entry: sessionTokens.entrySet()) {
		System.out.println(entry.getKey() + " -> " + entry.getValue());
		
	}
	
	IdentityHashMap<Integer, String> userIdentityMap = new IdentityHashMap<>();
	
	System.out.println("Enter the number of users: ");
	int m  = scan.nextInt();
	scan.nextLine();
	
	for (int i = 0; i < n; i++) {
		int userId = scan.nextInt();
        String userName = scan.next();
        userIdentityMap.put(userId, userName);
        System.out.println("Added User: " + userId + " -> " + userName);
	}
	
	System.out.println("Are the two users with the same data identical?" + userIdentityMap.containsKey(1));
	scan.close();
}
}
