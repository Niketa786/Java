package CollectionFramework;

import java.util.Scanner;
import java.util.HashSet;
import java.util.Objects;

public class ImplementHasCodeEqualsMehtod {
public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	HashSet<Car> cars = new HashSet<>();
	int n = scan.nextInt();
	scan.nextLine();
	
	for(int i = 0; i < n; i++) {
		String model = scan.next();
		int year = scan.nextInt();
		Car car = new Car(model, year);
		cars.add(car);
	}
	
	System.out.println("Unique cars in the HashSet: ");
	for(Car car: cars) {
		System.out.println(car);
	}
	scan.close();
}
}
