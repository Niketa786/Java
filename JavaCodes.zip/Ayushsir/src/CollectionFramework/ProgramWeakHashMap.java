package CollectionFramework;
import java.util.*;
import java.util.HashMap;

public class ProgramWeakHashMap {
public static void main(String[] args) {
	List<Student> classA = new ArrayList<Student>();
	List<Student> classB = new ArrayList<Student>();
	List<Student> classC = new ArrayList<Student>();
	
	Student s1 = new Student(1, "Ajay");
	Student s2 = new Student(2, "Amit");
	Student s3 = new Student(3, "anuj");
	
	classA.add(s1);
	classA.add(s2);
	classA.add(s3);
	
	Student s4 = new Student(4, "Bob");
	Student s5 = new Student(5, "Charlie");
	Student s6 = new Student(6, "Alice");
	
	classB.add(s4);
	classB.add(s5);
	classB.add(s6);
	
	Student s7 = new Student(7, "Suraj");
	Student s8 = new Student(8, "Mohit");
	Student s9 = new Student(9, "Rohit");
	
	classC.add(s7);
	classC.add(s8);
	classC.add(s9);
	
	HashMap<String, List<Student>> map = new HashMap<String ,List<Student>>();
	map.put("classA", classA);
	map.put("classB", classB);
	map.put("classC", classC);
	
	System.out.println("Accessing Student details for classB");
	List<Student> classBStudents = map.get("classB");
	
	for(Student st: classBStudents) {
		System.out.println(st);
	}
	
	System.out.println("Accessing Student details for all the classes");
	
	for (String Key: map.keySet()) {
	for (Student ClassList: map.get(Key)) {
		System.out.println(ClassList);
	}
	}
}
}
