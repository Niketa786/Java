package CollectionFramework;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class CollectionReverseMethod {
	public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
    ArrayList<String> cities = new ArrayList<>();
    
    for (int i = 1; i <=  5; i++) {
        cities.add(scan.nextLine());
    }
    
    Collections.reverse(cities);
    for (int i = 0; i <= cities.size()-1; i++) {
    	System.out.print(cities.get(i));
    	if (i < cities.size()-1) {
    		System.out.print(", ");
    	}
    }
    System.out.println();
}
	
}