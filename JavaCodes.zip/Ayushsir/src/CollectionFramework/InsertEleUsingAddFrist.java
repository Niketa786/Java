package CollectionFramework;

import java.util.LinkedList;
import java.util.Scanner;

public class InsertEleUsingAddFrist {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		LinkedList<String> tasks = new LinkedList<>();
		int n = Integer.parseInt(scan.nextLine());
		
		for(int i = 0; i < n; i++) {
			String task = scan.nextLine();
			tasks.addFirst(task);
		}
		
		System.out.println("Number of Tasks: " + tasks.size());
		System.out.println("Tasks: ");
		for(String task: tasks) {
			System.out.println(task);
		}
		scan.close();
	}
}
