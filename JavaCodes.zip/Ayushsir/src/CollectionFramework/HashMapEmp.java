package CollectionFramework;

import java.util.Map;
import java.util.HashMap;
import java.util.Scanner;

public class HashMapEmp {
public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	HashMap<Integer, String> hm = new HashMap<Integer, String>();
	int n = scan.nextInt();
	
	for (int i = 1; i <= n; i++) {
		int id = scan.nextInt();
		String name = scan.next();
		hm.put(id, name);
		System.out.println("Added: ID " + id + " -> " + name);
	}
	
	int retrieveID = scan.nextInt();
	String name = hm.get(retrieveID);
	
	if (name != null) {
		System.out.println("Employee name: " + name);
	} else {
		System.out.println("Emplloyee not found.");
	}
	
	int removeId = scan.nextInt();
	String removedName = hm.remove(removeId);
	if (removedName != null) {
		System.out.println("Employee removed: " + removedName);
	} else {
		System.out.println("Employee not found.");
	}
	
	for (Map.Entry<Integer, String> res: hm.entrySet()) {
		System.out.println("ID: " + res.getKey() + ", Name: " + res.getValue());
	}
	scan.close();
}
}
