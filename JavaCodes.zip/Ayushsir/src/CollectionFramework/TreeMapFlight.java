package CollectionFramework;

import java.util.TreeMap;
import java.util.Map;
import java.util.Scanner;

public class TreeMapFlight {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		TreeMap<String, String> tm = new TreeMap<String, String>();
		int n = scan.nextInt();
		
		for (int i = 1; i <= n; i++) {
			String flight = scan.next();
			String time = scan.next();
			tm.put(time, flight);
			System.out.println("Added: flight " + flight + " at " + time);
		}
		
		String retrieveTime = scan.next();
		String retrieveFlight = tm.get(retrieveTime);
		
		if (retrieveFlight != null) {
			System.out.println("Flight at " + retrieveTime + ": " + retrieveFlight);
		} else {
			System.out.println("No Flight found at " + retrieveTime);
		}
		
		String removeTime = scan.next();
		String removeFlight = tm.remove(removeTime);
		if (removeFlight != null) {
			System.out.println("Flight removed: " + removeFlight + " at " + removeTime);
		} else {
			System.out.println("No Flight found at " + removeTime);
		}
		
		for (Map.Entry<String, String> res: tm.entrySet()) {
			System.out.println("Roll: " + res.getKey() + ", Name: " + res.getValue());
		}
		scan.close();
	}
}
