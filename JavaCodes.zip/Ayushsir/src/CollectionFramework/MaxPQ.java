package CollectionFramework;

import java.util.Collections;
import java.util.PriorityQueue;
import java.util.Scanner;

public class MaxPQ {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int n = scan.nextInt();
		
		PriorityQueue pq = new PriorityQueue(Collections.reverseOrder());
		
		for(int i = 0; i < n; i++) {
			pq.add(scan.nextInt());
		}
		
		pq.add(scan.nextInt());
		System.out.println("Updated priority queue task of priorities: " + pq);
		scan.close();
}
}
