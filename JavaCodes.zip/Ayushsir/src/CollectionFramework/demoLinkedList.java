package CollectionFramework;
import java.util.LinkedList;
import java.util.Iterator;

public class demoLinkedList {
public static void main(String[] args) {
	LinkedList ll = new LinkedList();
	ll.add(100);
	ll.add(50);
	ll.add(150);
	ll.add(25);
	ll.add(125);
	ll.add(75);
	ll.add(175);
	ll.add(150);
	
//Traversing using for loop
	System.out.print("[");
	for (int i = 0; i <= ll.size()-1; i++) {
		if (i == ll.size()-1) {
			System.out.print(ll.get(i));
		}
		else {
			System.out.print(ll.get(i) + ", ");
		}
	}
	System.out.print("]");
	System.out.println();
	
	
//Traversing using for each loop	
	System.out.print("[");
	for(Object x: ll) {
		System.out.print(x + " ");
	}
	System.out.print("]");
	System.out.println();
	
	
//Travesing using iterator
	Iterator itr = ll.iterator();
	System.out.print("[");

	while (itr.hasNext()) {
	    System.out.print(itr.next());
	    if (itr.hasNext()) {
	        System.out.print(", ");
	    }
	}

	System.out.print("]");
}
}