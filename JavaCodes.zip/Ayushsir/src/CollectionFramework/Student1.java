package CollectionFramework;
import java.lang.Comparable;

public class Student1 implements Comparable<Student1> {
int roll;
String name;
double marks;

public Student1(int roll, String name, double marks) {
	this.roll = roll;
	this.name = name;
	this.marks = marks;
}

@Override
public String toString() {
	return roll + " " + name + " " + marks;
}

public int compareTo(Student1 obj) {
	return this.roll - obj.roll;
}
}

