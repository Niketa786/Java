package CollectionFramework;

import java.util.LinkedList;
import java.util.Scanner;

public class EleUsingAddLast {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int n = Integer.parseInt(scan.nextLine());
		
		LinkedList<String> customers = new LinkedList<>();
		
		for(int i = 0; i < n; i++) {
			String name = scan.nextLine();
			customers.addLast(name);
		}
		
		System.out.println("Queue size: " + customers.size());
		System.out.println("Customers: ");
		for(String customer: customers) {
			System.out.println(customer);
		}
		scan.close();
	}
}
