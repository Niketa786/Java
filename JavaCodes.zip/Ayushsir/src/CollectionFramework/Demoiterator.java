package CollectionFramework;
import java.util.ArrayList;
import java.util.Iterator;

public class Demoiterator {
public static void main(String[] args) {
	ArrayList al = new ArrayList();
	al.add(100);
	al.add(50);
	al.add(150);
	al.add(25);
	al.add(125);
	al.add(75);
	al.add(175);
	al.add(150);
	
//	System.out.println(al);
	
//	System.out.print("[");
//	for (int i = 0; i <= al.size()-1; i++) {
//		if (i == al.size()-1) {
//			System.out.print(al.get(i));
//		}
//		else {
//			System.out.print(al.get(i) + ", ");
//		}
//	}
//	System.out.print("]");
	
	Iterator itr = al.iterator();
	System.out.print("[");

	while (itr.hasNext()) {
	    System.out.print(itr.next());
	    if (itr.hasNext()) {
	        System.out.print(", ");
	    }
	}

	System.out.print("]");
}
}
