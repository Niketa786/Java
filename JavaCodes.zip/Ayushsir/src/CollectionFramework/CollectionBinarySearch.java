package CollectionFramework;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Collections;

public class CollectionBinarySearch {
public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
    ArrayList<Integer> numbers = new ArrayList<>();
    
    for (int i = 1; i <=  5; i++) {
        numbers.add(scan.nextInt());
    }
    int key = scan.nextInt();
    int idx = Collections.binarySearch(numbers, key);
    
    if(idx >= 0) {
    	System.out.println("The number " + key + " is found at " + idx + ".");
    } else {
    	System.out.println("The number " + key + " is not found.");
    }
    scan.close();
}
}
