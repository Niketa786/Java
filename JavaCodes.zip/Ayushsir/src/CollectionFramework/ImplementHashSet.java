package CollectionFramework;
import java.util.*;

public class ImplementHashSet {
public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	HashSet<Integer> employeeIDs = new HashSet<>();
	
	int n = scan.nextInt();
	for(int i = 0; i < n; i++) {
		int id = scan.nextInt();
		employeeIDs.add(id);
	}
	
	while(true) {
		String operation = scan.next();
		switch(operation) {
		case "ADD" : employeeIDs.add(scan.nextInt());
		System.out.println(employeeIDs);
		break;
		
		case "REMOVE" : employeeIDs.remove(scan.nextInt());
		System.out.println(employeeIDs);
		break;
		
		case "CHECK" : 
		if (employeeIDs.contains(scan.nextInt())) {
		System.out.println("YES");
		} else {
			System.out.println("NO");
		}
		break;
		
	case "PRINT" : 
		if (employeeIDs.isEmpty()) {
		System.out.println("EMPTY");
		} else {
			System.out.println(employeeIDs);
		}
		break;
		
		case "STOP" :
			return;
			
	default: System.out.println("Invalid operation!");		
	}
}
}
}