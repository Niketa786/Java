package CollectionFramework;

public class Person implements Comparable<Person> {
private String name;
private int age;

 Person(String name, int age) {
	this.name = name;
	this.age = age;
 }
 
 public int compareTo(Person obj) {
	 return this.age - obj.age;
}
 
 public String toString() {
	return "Person { name= '" + name + "', age = " + age + " } ";
}
}
