package CollectionFramework;

import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class Compare2LinkedList {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // 1. Read n1 representing the number of elements in the first list.
        int n1 = scanner.nextInt();
        scanner.nextLine(); // Consume the newline

        // 2. Read n1 integers and add them to the first LinkedList<Integer>.
        List<Integer> list1 = new LinkedList<>();
        String line1 = scanner.nextLine();
        String[] elements1 = line1.split(" ");
        
        for (int i = 0; i < n1 && i < elements1.length; i++) {
            if (!elements1[i].isEmpty()) {
                list1.add(Integer.parseInt(elements1[i]));
            }
        }

        // 3. Read n2 representing the number of elements in the second list.
        int n2 = scanner.nextInt();
        scanner.nextLine(); // Consume the newline

        // 4. Read n2 integers and add them to the second LinkedList<Integer>.
        List<Integer> list2 = new LinkedList<>();
        String line2 = scanner.nextLine();
        String[] elements2 = line2.split(" ");

        for (int i = 0; i < n2 && i < elements2.length; i++) {
            if (!elements2[i].isEmpty()) {
                list2.add(Integer.parseInt(elements2[i]));
            }
        }
        
        scanner.close();

        // 5. Compare the two LinkedLists to determine if they are identical.
        // The List.equals() method checks if both lists have the same size 
        // and contain the same sequence of elements.
        boolean areIdentical = list1.equals(list2);

        // 6. Print the result of the comparison.
        if (areIdentical) {
            System.out.println("The two LinkedLists are identical.");
        } else {
            System.out.println("The two LinkedLists are not identical.");
        }
    }
}