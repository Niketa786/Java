package CollectionFramework;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

//public class LaptopMain {
//public static void main(String[] args) {
//	Laptop l1 = new Laptop(1, "i5", 85000.0);
//	Laptop l2 = new Laptop(2, "i3", 75000.0);
//	Laptop l3 = new Laptop(3, "i7", 65000.0);
//	
//	ArrayList<Laptop> al = new ArrayList<Laptop>();
//	al.add(l1);
//	al.add(l2);
//	al.add(l3);
//	System.out.println(al);
//	
//	Collections.sort(al);
//	
//	System.out.println();
//}
//}


public class LaptopMain {
public static void main(String[] args) {
	Laptop l1 = new Laptop(1, "i5", 85000.0);
	Laptop l2 = new Laptop(2, "i3", 75000.0);
	Laptop l3 = new Laptop(3, "i7", 65000.0);
	
	ArrayList<Laptop> al = new ArrayList<Laptop>();
	al.add(l1);
	al.add(l2);
	al.add(l3);
	System.out.println(al);
	
	Collections.sort(al, new Comparator<Laptop>() {
   @Override
   public int compare(Laptop O1, Laptop O2) {
		return (int) (O2.price - O1.price);
	}
});
	System.out.println(al);
}
}