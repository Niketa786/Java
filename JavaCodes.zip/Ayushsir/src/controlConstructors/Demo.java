package controlConstructors;
import java.util.Scanner;

////this is if-Statement example-1

//public class Demo {
//public static void main(String[] args) {
//	Scanner scan = new Scanner(System.in);
//	System.out.println("Enter a number: ");
//	int num = scan.nextInt();
//	if(num > 10) {
//		System.out.println("Number is greater");
//	}
//}
//}


//this is if-Statement example-2

//public class Demo {
//public static void main(String[] args) {
//Scanner scan = new Scanner(System.in);
//	System.out.println("Enter a number: ");
//	int number = scan.nextInt();
//	checkMultiplyOf(number);
//	
//}
//public static void checkMltiplyOf(int number) {
//	if(number%5 == 0) {
//		System.out.println("Multiple of 5");
//	}
//		System.out.println("Program Ended");
//	
//}
//}


//this is if-else Statement example-1

//public class Demo {
//public static void main(String[] args) {
//	Scanner scan = new Scanner(System.in);
//	System.out.println("Enter a number: ");
//	int num = scan.nextInt();
//	if(num >= 0) {
//		System.out.println("Positive Number");
//	}
//	else {
//		System.out.println("Negative Number");
//	}
//}
//}


//this is if-else Statement example-2

public class Demo {
public static void main(String[] args) {
Scanner scan = new Scanner(System.in);
	System.out.println("Enter a number: ");
	int num = scan.nextInt();
	checkOddEven(num);
	
}
public static void checkOddEven(int num) {
	if(num%2 == 0) {
		System.out.println("EVEN");
	}
	else {
		System.out.println("ODD");
	}
}
}

























