package controlConstructors;

import java.util.Scanner;

//sum of N natural numbers
//public class Demo3 {
//public static void main(String[] args) {
//Scanner scan = new Scanner(System.in);
//System.out.println("Enter your number: ");
// int N = scan.nextInt();
//	int sum = 0;
//	for (int i = 1; i <= N; i++) {
//		sum = sum+i;
//	}
//	System.out.println(sum);
//	scan.close();
//}
//}


//public class Demo3 {
//public static void main(String[] args) {
//	for (int i = 1; i <= 10; i++) {
//	System.out.println(i);
//}
//}
//}


//product of odd number in b/w the range of 1 to  N numbers
//public class Demo3 {
//public static void main(String[] args) {
//Scanner scan = new Scanner(System.in);
//System.out.println("Enter your number: ");
// int N = scan.nextInt();
//	int product = 1;
//	for (int i = 1; i <= N; i++) {
//		if(i%2 != 0) {
//		product = product*i;
//		}
//	}
//	System.out.println(product);
//	scan.close();
//}
//}


public class Demo3 {
public static void main(String[] args) {
	int number = 5;
	for (int i = 1; i <= 10; i++) {
	System.out.println(number + "*" + i + " = " + (number*i));
	}
}
}















