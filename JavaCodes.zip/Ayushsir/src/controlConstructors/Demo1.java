package controlConstructors;
import java.util.Scanner;

//else-if ladder example-1

//public class Demo1 {
//	
//	public static void main(String[] args) {
//		Scanner scan = new Scanner(System.in);
//		System.out.println("Enter a dayNumber: ");
//		int day = scan.nextInt();
//		checkPositiveNegative(day);
//		
//	}
//		
//		public static void checkPositiveNegative(int day) {
//		if(day == 1) {
//			System.out.println("Weeekday");
//		}
//		else if(day == 2){
//			System.out.println("Weekday");
//		}
//		else if(day == 3){
//			System.out.println("Weekday");
//		}
//		else if(day == 4){
//			System.out.println("Weekday");
//		}
//		else if(day == 5){
//			System.out.println("Weekday");
//		}
//		else if(day == 6){
//			System.out.println("Weekend");
//		}
//		else {
//			System.out.println("Weekend");
//	}
//	
//	}
//}


//else-if ladder example-2


public class Demo1 {
	
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter a Number: ");
		int number = scan.nextInt();
		checkPositiveNegative(number);
		
	}
		
		public static void checkPositiveNegative(int number) {
		if(number >= 90 && number <= 100) {
			System.out.println("Grade A");
		}
		else if(number >= 80 && number <= 89){
			System.out.println("Grade B");
		}
		else if(number >= 60 && number <= 79 ){
			System.out.println("Grade C");
		}
	    else if(number >= 35 && number <= 59 ){
			System.out.println(" Grade D");
		}
		else {
			System.out.println("fail");
	}
	
	}
}
