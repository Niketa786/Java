package controlConstructors;

import java.util.Scanner;

//print even no. 1 to 50
//public class Demo5 {
//public static void main(String[] args) {
//	Scanner scan = new Scanner(System.in);
//	System.out.println("enter number");
//	int n = scan.nextInt();
//	int i = 1;
//		do {
//	if (i%2 == 0) {
//		System.out.println(i);
//		}
//	i++;
//}while(i <= n);
//		scan.close();
//}
//}

//print table
//public class Demo5 {
//public static void main(String[] args) {
//	Scanner scan = new Scanner(System.in);
//	int number = 5;
//	int multiplier = 1;
//		do {
//	System.out.println(number + "*" + multiplier + " = " + (number*multiplier));
//	multiplier++;
//}while(multiplier <= 10);
//		scan.close();
//}
//}

//factorial calculate of 2 values
//public class Demo5 {
//public static void main(String[] args) {
//	Scanner scan = new Scanner(System.in);
//	System.out.println("Enter first number: ");
//	int N = scan.nextInt() ;
//	System.out.println("Enter second number: ");
//	int M = scan.nextInt() ;		
//	int fact1 = 1;
//	int fact2 = 1;
//	do {
//		fact1 *= N;
//		N--; 
//		fact2 *= M;
//		M--;
//}while(N > 0 && M > 0); 
//	System.out.println(fact1);
//	System.out.println(fact2);
//	scan.close();
//}
//}

public class Demo5 {
public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	System.out.println("Enter first number: ");
	int N = scan.nextInt() ;
	System.out.println("Enter second number: ");
	int M = scan.nextInt() ;		
	int factN = 1;
	int factM = 1;
	int i = 1;
	int j = 1;
	do {
		factN *= i;
		i++; 
	}while(i <= N);
	System.out.println("Factorial of "+ N + " is " + factN);
	do {
		factM *= j;
		j++;
}while(j <= M); 
	System.out.println("Factorial of "+ M + " is " + factM);
	scan.close();
}
}





















