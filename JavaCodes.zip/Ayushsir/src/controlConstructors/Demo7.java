package controlConstructors;

import java.util.Scanner;

//public class Demo7 {
//public static void main(String[] args) {
//	for (int i = 1; i<= 10; i++) {
//		System.out.println(i);
//		if(i == 6) {
//			break;
//		}
//	}
//}
//}

//public class Demo7 {
//public static void main(String[] args) {
//	for (int i = 1; i<= 10; i++) {
//		if(i == 4) {
//			continue;
//		}
//	System.out.println(i);
//}
//}
//}

//public class Demo7 {
//public static void main(String[] args) {
//	for (int i = 1; i<= 10; i++) {
//		
//		if(i%5 == 0) {
//			break;
//		}
//		System.out.println(i);
//}
//}
//}

//public class Demo7 {
//public static void main(String[] args) {
//	int sum = 0;
//	for (int i = 1; i<= 10; i++) {
//		
//		if(i%3 == 0) {
//			continue;
//		}
//		sum += i;
//	}
//		System.out.println(sum);
//}
//}

//public class Demo7 {
//public static void main(String[] args) {
//	Scanner scan = new Scanner(System.in);
//	System.out.println("Enter Number");
//	int n = scan.nextInt();
//		int i = 1;
//		while (i <= n) {
//		if (i== 3) {
//			i++;
//			continue;
//		}
//	System.out.println(i);
//	i++;
//}	
//		scan.close();
//}
//}

//public class Demo7 {
//public static void main(String[] args) {
//	Scanner scan = new Scanner(System.in);
//	System.out.println("Enter Number");
//	int n = scan.nextInt();
//	
//		int i = 1;
//		
//		System.out.print("Numbers: ");
//		
//		while (i <= n) {
//		if (i%3 ==0 && i%5 == 0) {
//			i++;
//			continue;
//		}
//	System.out.print(" i " + i);
//	i++;
//}	
//		scan.close();
//}
//}

//public class Demo6 {
//public static void main(String[] args) {
//	for (int i = 1; i<= 3; i++) {
//		for (int j = 1; j <= 4; j++) {
//			System.out.println("i: " + i + "j: " + j);
//		}
//	}
//}
//}//public class Demo6 {
//public static void main(String[] args) {
//for (int i = 1; i<= 3; i++) {
//	for (int j = 1; j <= 4; j++) {
//		System.out.println("i: " + i + "j: " + j);
//	}
//}
//}
//}

//public class Demo7 {
//public static void main(String[] args) {
//	for (int i = 1; i<= 3; i++) {
//		for (int j = 1; j <= 4; j++) {
//			if (j == 2) {
//				break;
//			}
//			System.out.println("i: " + i + "j: " + j);
//		}
//	}
//}
//}

//public class Demo7 {
//public static void main(String[] args) {
//	for (int i = 1; i<= 3; i++) {
//		for (int j = 1; j <= 4; j++) {
//			if (j == 2) {
//				continue;
//			}
//			System.out.println("i: " + i + "j: " + j);
//		}
//	}
//}
//}

//public class Demo7 {
//public static void main(String[] args) {
//	for (int i = 1; i<= 3; i++) {
//		for (int j = 1; j <= 4; j++) {
//			if (i == 2) {
//				break;
//			}
//			System.out.println("i: " + i + "j: " + j);
//		}
//	}
//}
//}

//labeled loop example
public class Demo7 {
public static void main(String[] args) {
	outer: for (int i = 1; i<= 3; i++) {
		inner: for (int j = 1; j <= 4; j++) {
			if (i == 2) {
				break outer;
			}
			System.out.println("i: " + i + "j: " + j);
		}
	}
}
}



