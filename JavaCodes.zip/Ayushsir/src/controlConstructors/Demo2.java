package controlConstructors;

import java.util.Scanner;

//public class Demo2 {
//public static void main(String[] args) {
//	Scanner scan = new Scanner(System.in);
//	System.out.println("Enter a Number:");
//	int num = scan.nextInt();
//	switch(num) {
//	case 1 :
//		System.out.println("ONE");
//		break;
//	case 2 :
//		System.out.println("TWO");
//		break;
//	case 3 :
//		System.out.println("THREE");
//		break;
//	case 4 :
//		System.out.println("FOUR");
//		break;
//		default :
//			System.out.println("Invalid number.");
//			
//	}
//}
//}


//public class Demo2 {
//public static void main(String[] args) {
//	Scanner scan = new Scanner(System.in);
//	System.out.println("Enter a Number:");
//	int num = scan.nextInt();
//	switch(num) {
//	
//	
//	case 1 :
//	case 2 :
//	case 12:
//		System.out.println("Winter");
//		break;
//		
//		//OR 
////	case 1,2,12 :
////		System.out.println("Winter");
////        break;
//	case 3 :
//	case 4 :
//	case 5:
//		System.out.println("Spring");
//		break;
//	case 6 :
//	case 7 :
//	case 8:
//		System.out.println("Summer");
//		break;
//	case 9 :
//	case 10 :
//	case 11:
//		System.out.println("Autumn");
//		break;
//		default :
//			System.out.println("Invalid Season");
//			
//	}
//}
//}


public class Demo2 {
public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	System.out.println("Enter a color:");
	char lightColor = scan.next().charAt(0);
	switch(lightColor) {
	
	
	case 'R' :
		System.out.println("Stop");
		break;
	case 'Y' :
		System.out.println("Wait");
		break;
	case 'G' :
		System.out.println("Go");
		break;
		default :
			System.out.println("Invalid color.");
			
	}
	scan.close();
}
}



















