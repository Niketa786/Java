package controlConstructors;

//public class Demo6 {
//public static void main(String[] args) {
//	for (int i = 1; i<= 3; i++) {
//		for (int j = 1; j <= 4; j++) {
//			System.out.println("i: " + i + "j: " + j);
//		}
//	}
//}
//}

//public class Demo6 {
//public static void main(String[] args) {
//	int i = 1;
//	while(i<=3) {
//		int j = 1; 
//		while(j <= 4) {
//			System.out.println("i: " + i + "j: " + j);
//			j++;
//		}
//		i++;
//	}
//}
//}

//public class Demo6 {
//public static void main(String[] args) {
//	int i = 1;
//	 do{
//		int j = 1; 
//		while(j <= 4) {
//			System.out.println("i: " + i + "j: " + j);
//			j++;
//		}	while(j <= 4);
//		i++;
//	}while(i<=3);
//}
//}

public class Demo6 {
public static void main(String[] args) {
	for(int i = 1; i <= 2; i++) {
		
	int j = 1;
	while (j <= 3) {
		int k = 1; 
		do {
			System.out.println("i : " + i + "  "+"j : " + j +"  "+"k : " + k);
			k++;
		}while(k <= 2);
		j++;
	}
}
}
}






















