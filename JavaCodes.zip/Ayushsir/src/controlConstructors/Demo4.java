package controlConstructors;
import java.util.Scanner;

//public class Demo4 {
//public static void main(String[] args) {
//	int i = 1;
//	while(i <= 10) {
//		System.out.println(i);
//		i++;
//	}
//}
//}

//sum of 1 to 10
//public class Demo4 {
//public static void main(String[] args) {
//	int i = 1;
//	int sum = 0;
//	while(i <= 10) {
//		sum += i;
//		i++;
//}
//	System.out.println(sum);
//}
//}

//factorial calculate
//public class Demo4 {
//public static void main(String[] args) {
//	int num = 5;
//	int fact = 1;
//	while(num > 0) {
//		fact *= num;
//		num--;
//}
//	System.out.println(fact);
//}
//}


//public class Demo4 {
//public static void main(String[] args) {
//	int num = 1;
//	int product = 1;
//	while(num <= 5) {
//		product *= num;
//		num++;
//}
//	System.out.println(product);
//}
//}

//print even numbers
//public class Demo4 {
//public static void main(String[] args) {
//	Scanner scan = new Scanner(System.in);
//	System.out.println("enter number");
//	int n = scan.nextInt();
//	int i = 1;
//		while(i <= n) {
//		if (i%2 == 0) {
//	System.out.println(i);
//		}
//	i++;
//}
//		scan.close();
//}
//}


public class Demo4 {
public static void main(String[] args) {
	int number = 5;
	int multiplier = 1;
	while(multiplier <= 10) {
	System.out.println(number + "*" + multiplier + " = " + (number*multiplier));
	multiplier++;
	}
}
}















