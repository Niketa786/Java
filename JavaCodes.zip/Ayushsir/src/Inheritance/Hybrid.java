package Inheritance;

public class Hybrid {
	String name;
	 
	 void introduce() {
		 System.out.println("Hello, my name is " + name + ".");
	 }
	}

	class Professor2 extends Hybrid {
		String dept;
		
		void conductLecture() {
			System.out.println(name + " is conducting a lecture.");
		}
	}

class Student1 extends Hybrid {
	String major;
	
	void attendLecture() {
		System.out.println(name + " is attending a lecture.");
	}
}

class ResearchAssistent extends Student {
	String researchTopic;
	
	void conductLecture() {
		System.out.println(name + " is conducting lecture as a research assistant.");
	}
}















































































































































































































