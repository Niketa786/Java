package Inheritance;

public class ProgramMain {
public static void main(String[] args) {
	Program1 p1 = new Program1();
	p1.display();
	
	Program2 p2 = new Program2();
	p2.display();
}
}
