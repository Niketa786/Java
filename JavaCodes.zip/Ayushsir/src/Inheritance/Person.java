package Inheritance;

public class Person {
 String name;
 
 void introduce() {
	 System.out.println("Hello, my name is " + name + ".");
 }
}

class Professor extends Person {
	String dept;
	
	void conduct() {
		System.out.println(name + " is conducting a lecture.");
	}
}