package Inheritance;

public class Person1 {
	 String name;
	 int id;
	 
	 void introduce() {
		 System.out.println("Hello, my name is " + name + ".");
	 }
}

class Employee extends Person1 {
	String dept;
	
	void work() {
		System.out.println(name + " is working...");
	}
}

class Manager extends Employee {
	int teamSize;
	
	void conductMeeting() {
		System.out.println(name + " is conducting a meeting.");
		System.out.println(name + " is from " + dept + "Department.");
	}
	
}