package Inheritance;

public class UniversityMain {
public static void main(String[] args) {
	Professor prof = new Professor();
	prof.name = "Harish Pathak";
	prof.dept = "Computer Science";
	prof.introduce();
	prof.conduct();
	Student st = new Student();
	st.name = "Niketa";
	st.major = "CSE";
	st.introduce();
	st.attendLecture();
}
}
