package Inheritance;

public class University {
	String name;
	 
	 void introduce() {
		 System.out.println("Hello, my name is " + name + ".");
	 }
	}

	class Professor1 extends University {
		String dept;
		
		void conduct() {
			System.out.println(name + " is conducting a lecture.");
		}
	}

class Student extends University {
	String major;
	
	void attendLecture() {
		System.out.println(name + " is attending a lecture.");
	}
}