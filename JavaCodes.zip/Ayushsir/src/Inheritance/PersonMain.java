package Inheritance;

public class PersonMain {
public static void main(String[] args) {
	Professor prof = new Professor();
	prof.name = "Harish Pathak";
	prof.dept = "Computer Science";
	prof.introduce();
	prof.conduct();
}
}
