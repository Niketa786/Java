package Inheritance;

public class HybridMain {
	public static void main(String[] args) {
		
	Professor2 proff = new Professor2();
	proff.name = "Harish Pathak";
	proff.dept = "Computer Science";
	proff.introduce();
	proff.conductLecture();
	Student1 st = new Student1();
	st.name = "Niketa";
	st.major = "CSE";
	st.introduce();
	st.attendLecture();
	ResearchAssistent R = new ResearchAssistent();
	R.name = "Raj";
	R.researchTopic = "IT";
	R.introduce();
	R.conductLecture();
}
}