package Inheritance;

public class Person1Main {
public static void main(String[] args) {
	Manager manager = new Manager();
	manager.id = 1;
	manager.name = "Alice Johnson";
	manager.dept = "Management";
	manager.teamSize = 5;
	
	manager.introduce();
	manager.work();
	manager.conductMeeting();
}
}
