package Inheritance;
//method Overriding features access modifiers

//1. parent class and child class overridden method must have same access modifier
//public class Program1 {
//
//	public void display() {
//		System.out.println("Inside the Program1.");
//		
//	}
//}
//
//class Program2 extends Program1 {
//	@Override
////it give error -> i.e.,  write public
//	 public void display() {
//		System.out.println("Inside the Program2.");
//		
//	}
//}


//2. if child class overridden method needs to have d/R access modifier , than it is possible only if, accessability is getting increased, not decreased
//public class Program1 {
//
//  protected void display() {
//		System.out.println("Inside the Program1.");
//		
//	}
//}
//
//class Program2 extends Program1 {
//	@Override
//  public void display() {
//		System.out.println("Inside the Program2.");
//		
//	}
//}

//public class Program1 {
//
//	  void display() {
//			System.out.println("Inside the Program1.");
//			
//		}
//	}
//
//	class Program2 extends Program1 {
//		@Override
//	protected void display() {
//			System.out.println("Inside the Program2.");
//			
//		}
//	}

//1. parent class and child class overridden method must have same return type
//public class Program1 {
//
//	  void display() {
//			System.out.println("Inside the Program1.");
//		}
//	}
//
//	class Program2 extends Program1 {
//		@Override
//		//if we write int it will give error there fore write void
//	void display() {
//			System.out.println("Inside the Program2.");
//		}
//	}


//if they have d/R return type then they should Co-Variant => the return type which have parent child relationship
//public class Program1 {
//
//	  Developer display() {
//			System.out.println("Inside the Program1.");
//			return new Developer();
//		}
//	}
//
//	class Program2 extends Program1 {
//		@Override
//		//if we write int it will give error there fore write void
//	JavaDeveloper display() {
//			System.out.println("Inside the Program2.");
//			return new JavaDeveloper();
//		}
//	}
//
//class Developer {
//	
//}
//
//class JavaDeveloper extends Developer {
//	
//}


//The Super Keyword
public class Program1 {

	int a = 10;
	public void display() {
		System.out.println("Inside Program1, value of a = " + a);
		System.out.println("Inside the Program1.");
		
	}
}

class Program2 extends Program1 {
	int a = 20;
	@Override
	 public void display() {
		System.out.println("Inside Program2, value of a = " + a);
		System.out.println("Inside Program2, value of Inherited a = " + super.a);
		super.display();
		System.out.println("Inside the Program2.");
		
	}
}








































































